# ContractorLocal - GET Parameter Security & Routing Specification

## 1. Overview
This document audits and maps all `$_GET` parameters utilized across the ContractorLocal backend APIs and view loaders. It serves to verify that no Personally Identifiable Information (PII) or sensitive financial data is ever transmitted via URL parameters, ensuring compliance with strict network security paradigms (even in localhost environments).

---

## 2. Parameter Audit List
*Last Updated: Module Implementation Phase (Copy-Center & Help-Center Integrations)*

### 2.1 Routing & State Parameters
- **`action`**
  - **Type:** String
  - **Usage:** The primary router flag used by every backend endpoint (`api.php` or view actions) to determine the requested controller operation (e.g., `list_periods`, `get_period`, `delete_punch`, `list_docs`, `save_document`, `delete_document`).
  - **PII Risk:** None. Purely operational command mapping.
- **`mode`**
  - **Type:** Integer (1, 2, or 3)
  - **Usage:** Utilized inside the **Copy-Center**'s `html_editor.php` to define the active operational rendering state:
    * `1` = Template Endpoint Initialization (Blank layout)
    * `2` = JSONic Draft Review (Editable rehydration)
    * `3` = Immutable Signature Record (Hard-locked read-only)
  - **PII Risk:** None. State identifier only.

### 2.2 Record Identifiers (Primary/Foreign Keys)
- **`id`**
  - **Type:** Integer
  - **Usage:** Identifies the specific primary key of a database record to fetch or delete across multiple modules (`CRM`, `time-tracker`, `activity-logger`).
  - **PII Risk:** None. Purely structural database keys.
- **`period_id`**
  - **Type:** Integer
  - **Usage:** A foreign key utilized by the `time-tracker` to fetch punches, attached jobs, and mapped activities for a specific operational period.
  - **PII Risk:** None.
- **`client_id`**
  - **Type:** Mixed (Integer in Sync-Hub; Regex-sanitized String `/^[a-f0-9A-Z_-]+$/` in Copy-Center)
  - **Usage:** 
    * In `sync-hub`: Relational database integer foreign key.
    * In `copy-center`: Identifies the targeted filesystem-level Client ID directory under `shared/client_docs/<client_id>/`.
  - **PII Risk:** None. Structural/system key.
- **`sync_list_id`**
  - **Type:** Integer
  - **Usage:** Used by the `sync-hub` to retrieve specific items attached to a remote or synced activity list.
  - **PII Risk:** None.

### 2.3 Filesystem Discovery & Resource Loaders
- **`category`**
  - **Type:** String (Regex-sanitized `/^[a-zA-Z0-9_-]+$/`)
  - **Usage:** Specifying the dynamic subdirectory inside `/content/` to scan or load from inside **Help-Center** or **Copy-Center** (e.g., `bookkeeping`, `manpages`, `taxes`).
  - **PII Risk:** None. Map parameter.
- **`article`**
  - **Type:** String (Regex-sanitized `/^[a-zA-Z0-9_-]+$/`)
  - **Usage:** Pinpoints the targeted article index folder under a Help-Center category directory.
  - **PII Risk:** None. Folder resource identifier.
- **`endpoint`**
  - **Type:** String (Regex-sanitized `/^[a-zA-Z0-9_-]+$/`)
  - **Usage:** Specifies which active HTML form template (e.g., `test-contact-form`) is being initialized by `html_editor.php`.
  - **PII Risk:** None. Template identifier.
- **`file`** / **`filename`**
  - **Type:** String (Regex-sanitized `/^[a-zA-Z0-9_.-]+$/`)
  - **Usage:** Specifies the targeted file (raw PDF or JSON payload) to be opened, hydrated, or deleted inside `pdf_manager.php`, `client_docs.php`, and `html_editor.php`.
  - **PII Risk:** None. Filename references only.

### 2.4 Pagination & Structural Parameters (Sync Hub)
- **`table`**
  - **Type:** String (Strictly sanitized via regex `[^a-zA-Z0-9_]`)
  - **Usage:** Informs the `sync-hub` which generic database table it should query for bulk data dumps.
  - **PII Risk:** None.
- **`pk`**
  - **Type:** String (Strictly sanitized via regex `[^a-zA-Z0-9_]`)
  - **Usage:** Defines the name of the primary key column when the `sync-hub` is performing a dynamic deletion.
  - **PII Risk:** None.
- **`limit`**
  - **Type:** Integer (Cast to `int`)
  - **Usage:** Defines the maximum row count for Sync Hub pagination.
  - **PII Risk:** None.
- **`offset`**
  - **Type:** Integer (Cast to `int`)
  - **Usage:** Defines the starting row offset for Sync Hub pagination.
  - **PII Risk:** None.

### 2.5 Categorical Filters
- **`type`**
  - **Type:** String
  - **Usage:** Used in the `CRM` module to filter entities by type (e.g., Client, Contractor, DBA) during list fetches.
  - **PII Risk:** None. Categorical data only.

---

## 3. Security Conclusion
100% of all `$_GET` variables utilized by the system are strictly structural and architectural. They consist exclusively of routing commands, state values, integer IDs, sanitized sub-directory mappings, pagination metrics, and filtered categories. All Personally Identifiable Information (PII), financial payload data, and user input are strictly transmitted via JSON payloads within standard encrypted `POST` request bodies.

---



```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
```
