# ContractorLocal - Backup Center Architectural & Security Specification

## 1. Overview & Security Mandate
The **Backup Center** is a portable, zero-configuration data utility designed to preserve data integrity across the ContractorLocal ecosystem. 

### 1.1 Zero-Knowledge Data Protection Axiom
In strict alignment with the application's zero-knowledge security posture:
* **No Database Decryption:** The Backup Center **never** accesses the decrypted contents of database tables. It does not require or load the user's Master Password or Vault Key to create backups.
* **Encrypted Byte Transfer:** The utility operates strictly on the physical file system level, reading the already-encrypted raw bytes of the SQLCipher `.sqlite` files inside `/databases/` and packaging them.
* **Cryptographic Portability:** Because the database files are backed up in their encrypted SQLCipher states, the exported backup archive `.zip` is safe to store in un-encrypted local folders, cloud spaces, or USB drives. The data remains completely unreadable and cryptographically secured without the user's Zero-Knowledge Vault Key.

---

## 2. Directory Layout & Routing
The Backup Center utilizes the standard filesystem-routed module pattern, exposing a frontend SPA control interface and a decoupled backend processing API.

### 2.1 File System Map
```
/public/modules/backup-center/
├── index.php             # Main SPA control interface (Old School Premium UI)
├── module.ini            # Metadata manifest for module discovery
├── api/
│   └── api.php           # Core Backup Backend API (Export, Import, Undo)
```

---

## 3. Decoupled Dynamic Scan Architecture
To prevent path-drift bugs and maintain absolute compatibility with changing database layouts (such as our migration to the conjoined 3-DB sandbox model), the Backup Center operates on a **Decoupled Dynamic Scan Strategy**. 

* **No Hardcoded Filenames:** The API does not maintain a static index of active databases or modules.
* **System Directory Resolution:** The API resolves the physical database storage path dynamically:
  ```php
  $dbDir = realpath(__DIR__ . '/../../../../databases');
  ```
* **Dynamic sqlite Registry:** The system scans the resolved directory at runtime, identifying active databases by matching files ending in `.sqlite` that do not contain the recovery sideline token `_restore_backup_`.

---

## 4. API Endpoints & Core Workflows

```mermaid
graph TD
    A[Backup API Client] -->|action=export| B(Generate Zip + Manifest)
    A -->|action=import| C(Sideline Active DBs + Extract Zip)
    A -->|action=undo| D(Strip Sideline Suffix + Rename back)
```

### 4.1 Export Workflow (`action=export`)
Generates a portable, compressed ZIP archive containing all active SQLite sandboxes and a state manifest.

1. **Manifest Construction:** Instantiates an array capturing the export environment's timestamp, human-readable date, and a registry list of active database files.
2. **ZIP Archiving:** Spawns a temporary zip archive in the system's temp space using PHP's native `ZipArchive` class.
3. **Database Packaging:** Iterates through the scanned active databases, appending each `.sqlite` file directly into the ZIP archive.
4. **Manifest Binding:** Encodes `manifest.json` and writes it to the root of the ZIP.
5. **Download Streaming:** Sets browser HTTP download headers (`Content-Type: application/zip`) and streams the archive directly to the client as:
   `ContractorLocal_Backup_YYYYMMDD_HHMM.zip`
6. **Zero-Disk Footprint Cleanup:** The temporary file in `sys_get_temp_dir()` is immediately unlinked (`unlink()`) after streaming to prevent server-side data residue.

---

### 4.2 Import Workflow (`action=import`)
Restores database sandboxes from an uploaded ZIP archive while maintaining a dynamic safety fallback.

1. **Zip Verification:** Opens the uploaded file via `ZipArchive` and extracts `manifest.json`. If missing or invalid, the upload fails closed and returns an error.
2. **Sidelining Safety Net:** To prevent accidental data destruction, the API performs an automatic, in-place backup of the *currently active* databases:
   - Scans `/databases/` for active `.sqlite` files.
   - Renames each active file by appending the recovery suffix:
     `[database_name].sqlite_restore_backup_[timestamp]`
3. **Archive Extraction:** Iterates through the database filenames listed in the verified `manifest.json` registry and extracts their raw bytes directly into the `/databases/` directory.

---

### 4.3 Recovery Undo Workflow (`action=undo`)
Allows the administrator to roll back a database restoration, reinstating the sidelined databases to active status.

1. **Active Sidelining:** Sidelines the currently active databases (the ones that were just restored) to a new rollback timestamp, protecting current data.
2. **Suffix Stripping & Renaming:** Scans the databases directory matching the target restore timestamp suffix:
   `_restore_backup_[target_timestamp]`
3. The suffix is stripped and the sidelined files are renamed back to their original `.sqlite` names, restoring the exact state prior to the backup import.

---

## 5. Security & Verification
1. **Authentication Gate:** The Backup API enforces strict authentication. The thread immediately aborts with a `401 Unauthorized` response unless the secure volatile session key `db_key` is supplied via cookie or structural request parameters.
2. **Byte-for-Byte Preservation:** The file streaming and extraction layers operate exclusively on raw binary data streams (`OPENSSL_RAW_DATA` equivalent buffers), guaranteeing that encryption headers, salts, and page sizes are preserved exactly.

---

#&nbsp;Copyright (c) 2026:
#&nbsp;vatofichor&nbsp;-&nbsp;Sebastian Mass&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[&gt;_&lt;]
#&nbsp;&amp;&nbsp;Assisted By Gemini Antigravity&nbsp;/|\  
