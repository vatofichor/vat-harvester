# ContractorLocal - CORS & Data Ingestion Security Specification

## 1. Overview
This document specifies the boundaries, sanitation protocols, and server-side safeguards implemented to protect the local environment from arbitrary code execution during document ingestion (e.g., via the Copy-Center `import.php` endpoint).

---

## 2. File Upload Hardening

### 2.1 Extension Whitelisting
The ingestion endpoint strictly rejects any uploaded file that does not match the exact extension whitelist:
* **Allowed Extensions**: `.pdf`, `.json`
* **Blocked Extensions**: `.php`, `.phtml`, `.phps`, `.html`, `.exe`, etc.

### 2.2 Filename Sanitation
To prevent Directory Traversal attacks (e.g., `../../malicious_file.json`), the uploaded filename is aggressively sanitized before storage:
* **Regex Implementation**: `preg_replace('/[^a-zA-Z0-9_-]/', '_', pathinfo($fileName, PATHINFO_FILENAME))`
* This converts any non-alphanumeric character (including periods and slashes) into underscores, forcing the file to remain strictly within its assigned client directory.

### 2.3 Binary Header / MIME Validation
Relying purely on file extensions is insecure. The backend aggressively validates the raw magic bytes of uploaded files:
* **PDF Validation**: Extracts the first 5 bytes of the incoming binary and strictly asserts they match `%PDF-`.
* **JSON Validation**: Decodes the raw binary payload using `json_decode()` and asserts `json_last_error() === JSON_ERROR_NONE`.
* **Result**: Any file attempting to masquerade its true content via a spoofed extension is immediately rejected with a `400 Bad Request`.

---

## 3. Server-Side Execution Safeguards

### 3.1 Apache/Webserver Engine Lock (`.htaccess`)
Even with extreme application-level validation, Defense-in-Depth requires the webserver itself to refuse executing scripts inside upload directories.

The `/shared/` directory (which houses all client documents) is permanently locked via a dedicated `.htaccess` file:
```apache
# Disable PHP engine to prevent arbitrary script execution of uploaded files
php_flag engine off
RemoveHandler .php
<Files *>
    SetHandler default-handler
</Files>
```
* **Effect**: If an attacker somehow bypasses the application layer and uploads a malicious `.php` file, Apache will serve the raw text rather than executing the code, completely neutralizing the exploit.

---



```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
```
