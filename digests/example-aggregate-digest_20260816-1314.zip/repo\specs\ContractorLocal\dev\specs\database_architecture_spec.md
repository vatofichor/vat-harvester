# ContractorLocal - Database Architecture & Conjoined Sandbox Specification

## 1. Core Technology Stack
ContractorLocal utilizes a highly optimized, local-first database architecture designed for zero-configuration portability, absolute file sandbox security, and high performance.

- **Database Engine:** SQLite3
- **Encryption Layer:** SQLCipher (AES-256 Full Database Encryption, running as a secure no-op in local development environments where SQLCipher isn't compiled)
- **Driver:** PHP Data Objects (PDO) via `server/db.php`
- **Volatile Key Custody:** Encryption keys are never written to disk. The 256-bit Key Derivation (Argon2id) is loaded via HttpOnly cookies and injected only in memory using `PRAGMA key`. Key variables are immediately zeroed out in PHP RAM after connection binds.

---

## 2. Structural Paradigm: Conjoined Database Sandboxes
Instead of maintaining a separate SQLite file for every individual module (which creates massive connection overhead) or combining all sectors into one single monolithic file (which breaks zero-knowledge division of labor), ContractorLocal employs a **Conjoined Sandbox Architecture**. 

We segment the application's relational data into exactly **three isolated database files** residing in `/databases/`:

```
/databases/
├── crm_sector.sqlite      # The CRM Sector Sandbox
├── operations.sqlite      # The Core Operations Sandbox
└── sync_finance.sqlite    # The Sync Hub & Financial Sandbox
```

### 2.1 Sandbox Distribution Table
The database router in `server/db.php` maps active functional modules to these sandboxes:

| Module Name | Mapped Sandbox DB File | Key Identification Table |
| :--- | :--- | :--- |
| **CRM** (`crm`) | `crm_sector.sqlite` | `entities` |
| **Time-Tracker** (`time-tracker`) | `operations.sqlite` | `periods` |
| **Activity-Logger** (`activity-logger`) | `operations.sqlite` | `activity_lists` |
| **Job-Hub** (`job-hub`) | `operations.sqlite` | `jobs` |
| **Sync Hub** (`sync-hub`) | `sync_finance.sqlite` | `crm_clients` |
| **Billing Center** (`billing-center`) | `sync_finance.sqlite` | `invoices` |

### 2.2 Advantages of the Conjoined Model
1. **Intra-Database Relational Joins:** Because related modules (like Time-Tracker, Activity-Logger, and Job-Hub) share the same physical database file (`operations.sqlite`), they can execute native, ultra-fast SQL `JOIN` statements directly across tables without needing separate staging tables or PHP-level synchronization loops.
2. **Bookkeeping Sectors Boundary Isolation:** High-risk financial systems (Billing, Sync-Hub) and sensitive client CRM profiles are completely sandboxed in separate database files. This maintains cryptographic isolation between day-to-day work trackers and sensitive financial ledger accounts.
3. **Drastically Reduced Handles:** Reduces standard active SQLite file handles to exactly three, optimizing server memory and preventing file locks.

---

## 3. Modular Ingestion & Auto-Rebuild Schema Hardening
Because multiple modules now share a single physical database sandbox, the system employs **Module-Driven Schema Ingestion** to ensure clean, isolated schema generation without table conflicts.

### 3.1 The Key-Table Isolation Protocol
When a module requests a connection via `getDB($moduleName)`:
1. **Path Routing:** `getDB()` maps `$moduleName` to its physical sandbox (e.g., `operations.sqlite`) using the `$dbRouter` dictionary.
2. **Encrypted Spawn:** SQLite opens the file (spawning a fresh one if missing) and immediately binds the user's volatile key via `PRAGMA key`.
3. **Key-Table Existence Check:** Instead of verifying if the *entire database* is empty, the system checks specifically for the module's authoritative **Key Table** (defined in the `$moduleKeyTables` dictionary, e.g. checking for the table `periods` when initializing `time-tracker`):
   ```sql
   SELECT count(*) as cnt FROM sqlite_master WHERE type='table' AND name = :keyTableName
   ```
4. **On-Demand Schema Execution:** If the designated key table is missing, the system dynamically locates the schema file at `/public/modules/<moduleName>/schema.sql` and executes it. 

This ensures that when `time-tracker` and `job-hub` initialize sequentially inside `operations.sqlite`, they cleanly build their own discrete tables on top of each other without interfering with or overwriting tables belonging to the other conjoined modules.

---

## 4. Inter-Database Brokerage (Sync-Hub Boundary)
Because SQLite cannot execute relational joins across physically isolated sandboxes (such as joining `operations.sqlite` with `crm_sector.sqlite`), the system enforces two distinct relational integration paradigms:

1. **Option A (Relational Joins):** Enforced strictly for intra-database related data (e.g. time-tracker periods joining to activity logs inside `operations.sqlite`).
2. **Option B (Brokerage):** Enforced strictly at inter-database boundaries. The **Sync Hub** (`sync-hub`) acts as a headless cross-database mediator. Staged operational data is committed to `sync_finance.sqlite` via API triggers and mapped to clients using dedicated staging tables (`sync_jobs`, `sync_invoicable_time`).

### 4.1 Staging Integrity ("Rebuild-and-Commit" Axiom)
Sync Hub is a **one-way headless sync mediator**. 
* Operational modules stage transactions locally inside their own databases.
* Once staging is verified, the data is pushed to Sync-Hub, which records the mapping.
* If a sandbox database experiences bit-level corruption or is deleted:
  1. The administrator deletes the corrupted database file.
  2. The Auto-Rebuild sequence spawns a fresh database instantly.
  3. The uncommitted staged data is lost, and the user simply rebuilds the local operational edits and re-submits the sync to the hub. The centralized Sync Hub data remains un-corrupted and intact.

---

## 5. Corruption & Error Mitigation ("Fail Closed")
In alignment with Systems Mode security protocols, the database initialization layer is strictly fail-closed:

* **Detection:** Any decryption failure (wrong passphrase/vault key) or file corruption triggers a caught PDO Exception.
* **Failure Response:** The connection immediately shuts down, suppresses stack traces, and terminates the thread with a clear, safe JSON response:
  ```json
  {"error": "Database access denied. Invalid vault key or corrupted database."}
  ```
* **Administrative Recovery:** To restore module operations, the system administrator deletes the corrupted `.sqlite` file from `/databases/`. On the next application refresh, the Auto-Rebuild mechanic will cleanly regenerate the schema files from scratch.
