# ContractorLocal - Apache .htaccess & Sandbox Routing Specification

## 1. Directory Structure and Sandboxing Boundary

To protect sensitive databases, salts, credentials, and custom administrative scripts, ContractorLocal enforces a strict physical sandboxing layout. The directory tree separates the public web root (`/public/`) from the private backend modules and configuration space.

```
/ (Project Root)
├── .htaccess                   <-- Gateway: Rewrites all traffic silently to public/
├── config/                     <-- Private: Vault salts & master configuration [Ignored/Hidden]
├── databases/                  <-- Private: SQLite databases [Ignored/Hidden]
├── dev/                        <-- Private: Specs, admin scripts, development logs
├── lib/                        <-- Private: Launcher templates & installers
├── php/                        <-- Private: Portable PHP binaries [Ignored/Hidden]
├── server/                     <-- Private: Auth core, DB wrapper, encryption scripts
├── shared/                     <-- Private: Client documents, uploads, active drafts
└── public/                     <-- Web Root: Public assets and SPA entry points
    ├── .htaccess               <-- API Router: Redirects /server/* to router.php
    ├── assets/                 <-- Public CSS/JS files
    ├── modules/                <-- Decoupled SPA modules
    ├── index.php               <-- Web SPA entry point
    └── router.php              <-- Traversal-safe router / API gateway
```

---

## 2. Apache .htaccess Routing Configuration

### 2.1 Root Gateway Rewrite Rule (`/.htaccess`)
The root `.htaccess` acts as a silent traffic diverter. It intercepts all incoming requests to the domain and redirects them to the `/public/` directory without exposing the directory structure in the client's URL.

```apache
# ContractorLocal - Root Gateway Redirect
# Silently rewrites all incoming web requests into the public/ web root.
<IfModule mod_rewrite.c>
    RewriteEngine On
    
    # Do not rewrite if the request is already pointing to the public/ folder
    RewriteCond %{REQUEST_URI} !^/public/
    
    # Rewrite all traffic silently into public/
    RewriteRule ^(.*)$ public/$1 [L]
</IfModule>
```

### 2.2 Public API Route Rule (`/public/.htaccess`)
Once inside the web root, requests targeting the `/server/*` endpoints (such as `server/auth.php`) must be securely routed to the backend directory, which sits above the web root. 

```apache
# ContractorLocal - Public Directory Routing
# Routes API and server requests to the traversal-safe custom router.
<IfModule mod_rewrite.c>
    RewriteEngine On
    
    # Route all /server/* requests through the router.php dispatcher
    RewriteRule ^server/(.*)$ router.php [L,QSA]
</IfModule>
```

---

## 3. Directory Traversal and Directory Exposure Protections

To prevent malicious path traversal and directory listings, multiple layers of defensive configuration are applied.

### 3.1 Custom PHP Router Safeguards (`/public/router.php`)
The custom router intercepts all API requests and runs verification checks to prevent directory traversal and directory listing attempts:
1. **Traversal Block:** Rejects any request URI containing traversal patterns (`..` or `/./`) with a `400 Bad Request` page.
2. **Slash Normalization:** Collapses duplicate slashes (e.g. `//config/`) via regex `preg_replace('#/+#', '/', $path)` to prevent prefix bypass attempts.
3. **Protected Folders Block:** Explicitly intercepts and blocks requests matching protected directories (`/config/`, `/databases/`, `/ai_persistent_files/`, `/php/`) with a `403 Forbidden` response.
4. **Backend Routing:** Resolves `/server/*` requests securely using absolute paths: `$backendFile = __DIR__ . '/..' . $path`.

### 3.2 Secure File Upload & Document Sandbox (`/shared/`)
The `/shared/` folder contains sensitive uploaded files and client agreements. While it sits safely outside the `/public/` directory root, additional safeguards are configured to prevent remote code execution if a PHP file is uploaded:

Inside `/shared/.htaccess`:
- **Disable PHP Engine:** `php_flag engine off` to turn off PHP execution on Apache servers.
- **Handler Disabling:** `<FilesMatches>` rule removing handlers for `.php`, `.phtml`, `.php5`, etc. to prevent PHP-FPM or FastCGI gateways from executing the file.
- **Force Download / Mime Types:** Restricts file interpretations.

### 3.3 Admin & Spec Access Controls (`/dev/`)
The `/dev/` directory contains specifications and administrative scripts (e.g. password resets, rebuild databases) that are strictly executable only via local terminal command-line interface (CLI) commands. They cannot be executed or read by web clients.
- Every script in `/dev/admin_scripts/` starts with a SAPI CLI check:
  ```php
  if (php_sapi_name() !== 'cli') {
      http_response_code(403);
      exit("Error: This script must be run from the Command Line Interface (CLI).\n");
  }
  ```
- Because the `/dev/` folder is placed outside of `/public/`, it remains completely invisible to the internet.
