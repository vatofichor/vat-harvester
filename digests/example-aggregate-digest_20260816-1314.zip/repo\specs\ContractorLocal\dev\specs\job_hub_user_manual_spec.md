# Job Hub User Manual Specification

## 1. Overview & Architectural Purpose
The **Job Hub** module acts as the core operational Job Costing center of the ContractorLocal platform. Its primary purpose is to aggregate various project expenditures (such as material expenses, purchase orders, subcontractor bills, and manual job costs) against specific client contracts (`JobID`s), preparing these consolidated costs for downstream billing, invoicing, and time-tracking integrations.

Rather than building a complex, tightly-coupled monolithic accounting system, Job Hub operates on a sandboxed, event-driven staging architecture that bridges the **Operations Sector** (`operations.sqlite`) and the **Finance Sector** (`sync_finance.sqlite`).

---

## 2. Staging & Costing Pipeline
The Job Hub workflow operates on a strict **Stage-Link-Publish** cycle to enforce double-billing protection:

```mermaid
graph TD
    A[Billing Center Transaction] -->|Stage for Costing| B(sync_staged_transactions)
    B -->|Link by Client or Vendor ID| C{Job Cost ledger}
    D[Manual Cost Items] -->|Log directly| C
    C -->|Stage Job to Sync-Hub| E(sync_jobs)
    E -->|Attach to Timecard| F[Timecard committed with job_total_cost]
    E -->|Map directly to Invoice| G[Invoice mapped and stuffed]
```

### A. Staging a Transaction
- Open the **Billing Center** transaction explorer.
- Locate any draft or finalized expense, purchase order, or vendor bill.
- Click **Stage for Costing**. The transaction is flagged in `sync_staged_transactions` and marked as available for costing.

### B. Linking Transactions to a Job
- Open the **Job Hub** and select a Job.
- The **Staged Client Expenditures** panel lists all available transactions staged for this client.
- **Subcontractor Reconciliation**: The picker automatically queries staged transactions matching **either** the Job's Client ID (materials purchased for the customer) OR the Job's Vendor ID (bills from subcontractors/contractors hired for the job).
- Click **Link to Job** to associate the transaction's cost to the Job's ledger. The transaction is immediately flipped to `is_staged = 0` to prevent double-costing.

### C. Logging Manual Expenditures
- Add manual out-of-pocket costs (e.g. municipal permits, quick cash expenses) directly within the **Manual Expenses Ledger** inside the Job detail panel.

### D. Pushing the Job to Sync-Hub
- Click **Stage Job to Sync-Hub** inside the Job detail panel.
- This aggregates the sum of linked transactions and manual costs, updates the Job metadata, and registers/refreshes the Job in the `sync_jobs` table with `is_closed = 0`.

---

## 3. Integration Synergies

### A. Time Tracker Integration (Timecard attachment)
- **Attachment**: Open a Timecard Period in the Time Tracker and click **Import Job**. Select the staged Job.
- **Auto-Closure**: Attaching a Job to a period automatically sets `is_closed = 1` in `sync_jobs` in the Sync-Hub. This immediately hides the Job from other timecards or billing mapper panels to prevent double-invoicing.
- **Cost Packaging**: When the user clicks **Commit Period to Invoice**, the system calculates the sum of all attached jobs' costs and transmits them under the `job_total_cost` parameter in the committed timecard payload.
- **Cascade Unstaging**:
  - Detaching a Job from a timecard period deletes the Job entry from `sync_jobs` (completely unstages it).
  - Deleting a parent period deletes all attached Jobs from `sync_jobs`.
  - **Rationale**: Forcing the Job to go back to an unstaged state ensures the bookkeeper must review the Job costing parameters in Job Hub before attempting to stage it again, eliminating complexity overhead.

### B. Billing Center Integration (Transaction Stuffing)
- **Mapper Drawer**: When editing/authoring a transaction in Billing Center, the visual mapper displays active staged timecards, activity lists, and jobs.
- **Direct Mapping**: Clicking **Map Job** fetches complete job details (description, manual cost ledger, linked transaction details), formats a technical log, and appends it to the target description/line items textarea:
  ```text
  [JOB: "Roof Repair - Main House"]
  - Description: Replace structural deck and lay shingles
  - Schedule: 2026-05-10 to 2026-05-20
  - Quantity / Default Rate: 10 @ $50.00/hr
  - Manual Expenses:
    - Permit: $150.00
  - Linked Transactions Cost:
    - TX #5 [2-60337-SIGNED]: $200.00
  - Total Job Cost Accumulation: $850.00
  ```
- **Pricing Hydration & Lockdown**:
  - If the active transaction template contains fields named `quantity` and `rate`, the mapper auto-fills them with the Job's `quantity` and `default_rate` properties, marks the fields as read-only (`readOnly = true`) to prevent editing, and computes:
    total_amount = (quantity * rate) + job_total_cost
  - If only `total_amount` or `amount` is present, it auto-fills it with `job_total_cost`.
- **Auto-Closure on Map**: Mapping the Job successfully triggers a backend hook to close the staged Job (`is_closed = 1`).
- **Cascade Unstaging & Reopening on Delete**:
  - Deleting a draft transaction parses the CSV file before disk unlinking.
  - Any imported `[JOB: "Name"]` entries are automatically deleted from `sync_jobs` (unstaged).
  - Any imported `[TIMECARD: Period #X]` entries are automatically reset to `is_closed = 0` (reopened).

---

## 4. Database Schema Specifications

### Operations Sandbox (`operations.sqlite`)
```sql
CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_name TEXT NOT NULL,
    client_id INTEGER NOT NULL,
    vendor_id INTEGER DEFAULT NULL,
    job_description TEXT,
    billed_status TEXT DEFAULT 'Not Billed',
    default_rate REAL DEFAULT 0.0,
    quantity REAL DEFAULT 1.0,
    budget_limit REAL DEFAULT 0.0,
    start_date TEXT,
    end_date TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS job_cost_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    amount REAL DEFAULT 0.0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(job_id) REFERENCES jobs(id) ON DELETE CASCADE
);
```

### Sync Finance Sandbox (`sync_finance.sqlite`)
```sql
CREATE TABLE IF NOT EXISTS sync_jobs (
    job_id INTEGER PRIMARY KEY,
    client_id INTEGER,
    vendor_id INTEGER,
    job_name TEXT,
    start_date TEXT,
    end_date TEXT,
    total_cost REAL DEFAULT 0.0,
    is_closed INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS sync_staged_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    billing_invoice_id INTEGER NOT NULL,
    client_id INTEGER NOT NULL,
    control_number TEXT UNIQUE NOT NULL,
    transaction_type TEXT NOT NULL,
    amount REAL DEFAULT 0.0,
    is_staged INTEGER DEFAULT 1,
    job_id INTEGER DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## 5. Security & Isolation Controls
- **DEK Memory Sanitization**: Connections to both sandboxes (`operations` and `sync_finance`) within a single API query require the HttpOnly vault key. Since `getDB()` immediately zeroes the cookie token on connection to prevent memory leaks, scripts opening multiple sandboxes must cache the DEK locally inside the execution thread and re-inject it before the second connection.
- **Hard Deletions**: Deleting a Job from the Job Hub dashboard cascadingly unlinks all staged transactions associated with that `job_id`, resetting their `is_staged` parameters to `1` and `job_id` parameters to `NULL`, preventing orphaned files.

---

## 6. Authorizations & Signature
```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
```
