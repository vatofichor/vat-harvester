# Systems Engineering Specification: Micro-MVC Routing Engine

This systems specification document outlines the technical architecture, dynamic discovery protocol, and client-side lifecycle execution of the ContractorLocal SPA Micro-MVC Routing Engine. It includes explicit patterns shared by modular subrouters and details the recovery protocol implemented for sticky subroutes in the **Help Center**.

---

## 1. Main Application Shell (Core SPA Router)

ContractorLocal operates as a pure Zero-Dependency, client-side Single Page Application (SPA). The main shell is initialized by [app.js](file:///d:/BOOKKEEPING/SEBASTIANMASS/ContractorLocal/assets/js/app.js) upon the `DOMContentLoaded` event.

### 1.1 Authentication & Session States
* **Unauthenticated State**: If `sessionStorage.getItem('logged_in')` is absent, the router intercepts the request and injects a volatile Vault Authentication UI (`renderAuth`).
  * If system configuration (`config/master.json`) is not found, the setup flow is triggered (`renderAuth('setup')`).
  * Otherwise, the login form is shown (`renderAuth('login')`).
* **Authenticated State**: Once a valid Master Password derives the SQLCipher DEK, the cookie `db_key` is established, `sessionStorage.setItem('logged_in', '1')` is set, and the client shell loads (`renderMainShell`).

### 1.2 Module Loading Lifecycle
The shell features a self-discovery sidebar navigation panel that loads modules dynamically without hardcoded menus.

```mermaid
sequenceDiagram
    participant User as Browser / User
    participant App as app.js (Client Shell)
    participant API as manifest.php (Server Manifest)
    participant Module as Module Controller (PHP)

    User->>App: Clicks nav sidebar button
    App->>API: secureFetch('server/manifest.php')
    API-->>App: Return list of enabled modules
    App->>Module: secureFetch('modules/{id}/{entry}')
    Module-->>App: Return raw HTML fragment + <script>
    App->>App: Inject HTML into #workspace
    App->>App: Extract, clone & execute script blocks
```

### 1.3 Injected Script Compilation Engine
Because module markup is injected directly into a persistent container (`document.getElementById('workspace').innerHTML = html`), standard HTML5 specs prevent `<script>` blocks inside dynamic injections from executing naturally.

To bypass this restriction, the Core SPA Router implements a custom DOM replacement loop:
```javascript
Array.from(workspace.querySelectorAll('script')).forEach(oldScript => {
    const newScript = document.createElement('script');
    Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
    newScript.appendChild(document.createTextNode(oldScript.innerHTML));
    oldScript.parentNode.replaceChild(newScript, oldScript);
});
```
* **Mechanism**: Every script element is recursively parsed, cloned (along with its original attributes), and appended to the workspace DOM to force V8 engine compilation and global scope evaluation.

---

## 2. Dynamic Discovery Protocol (`manifest.php`)

To support a decentralized, filesystem-first architecture, the server utilizes a **Self-Discovery Manifest Engine** inside [manifest.php](file:///d:/BOOKKEEPING/SEBASTIANMASS/ContractorLocal/server/manifest.php).

### 2.1 Directory Ingestion & Manifest Parsing
1. Scans `modules/` for children subdirectories.
2. If `modules/{dir}/module.ini` is present, it is parsed via PHP's native `parse_ini_file($iniPath, true)`.
3. Validates the existence of the `[module]` block:
   ```ini
   [module]
   name = "Help Hub"
   description = "Comprehensive business, bookkeeping, and tax guides"
   entry = "index.php"
   order = 5
   ```
4. The directory name is appended as the unique `id`.
5. **Sort Order**: The resulting manifest list is sorted programmatically using the spaceship operator (`<=>`) matching the explicit `order` parameter:
   ```php
   usort($manifest, function($a, $b) {
       $orderA = $a['order'] ?? 99;
       $orderB = $b['order'] ?? 99;
       return $orderA <=> $orderB;
   });
   ```

---

## 3. Modular Sub-routing Standard

Modules containing deep internal hierarchy (such as the Help Center or Copy Center) utilize an internal Subrouter inside their entry point (`index.php`).

### 3.1 Sub-workspace DOM Isolation
The module sets up its own isolated workspace container inside `index.php`:
```html
<div id="copy-center-workspace" class="module-body">
    <!-- Sub-views are injected here -->
</div>
```
All dynamic transitions within the module are confined strictly to this interior node, preventing mutations to the parent desktop navigation shell.

### 3.2 Dynamic View Loader
The subrouter object (e.g. `window.helpCenterApp`) exposes a `loadView(viewName, params)` controller. It utilizes the same innerHTML injection and script evaluation loop implemented by the parent shell, scoped strictly to the module workspace:
```javascript
loadView: async function (viewName, params = {}) {
    this.workspace.innerHTML = '<p style="color: var(--text-muted); text-align: center;">Loading...</p>';
    try {
        let url = `modules/help-center/views/${viewName}.php`;
        let queryStr = new URLSearchParams(params).toString();
        if (queryStr) url += `?${queryStr}`;

        const res = await secureFetch(url);
        if (!res.ok) throw new Error('View not found or unauthorized');

        const html = await res.text();
        this.workspace.innerHTML = html;

        // Re-evaluate script tags within the sub-workspace
        const scripts = this.workspace.querySelectorAll('script');
        scripts.forEach(oldScript => {
            const newScript = document.createElement('script');
            Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
            newScript.appendChild(document.createTextNode(oldScript.innerHTML));
            oldScript.parentNode.replaceChild(newScript, oldScript);
        });
    } catch (e) {
        this.workspace.innerHTML = `<p style="color: red;">Error: ${e.message}</p>`;
    }
}
```

### 3.3 Scope Redeclaration Prevention
Because sub-view scripts are dynamically compiled in the page's global context, declaring top-level variables using block-scoped `const` or `let` inside a view's `<script>` tag will throw a fatal `SyntaxError: Identifier has already been declared` if the user loads the same view twice.
* **Standard**: Sub-view scripts must exclusively use `var` for top-level variables, or enclose their code inside an IIFE (Immediately Invoked Function Expression) to protect variables from leaking to the global scope.

---

## 4. Help-Center Sticky Navigation (sessionStorage Recovery Protocol)

To optimize UX, the **Help Center** implements a custom **Sticky Recovery Protocol** that stores active navigation pathways. If a user clicks out of the Help Hub to complete a task in another module and returns, the router bypasses the hub index and restores their exact reading position.

### 4.1 Data Model
Sticky state is stored in `sessionStorage` under the key `help_center_last_view` as a serialized JSON object:
```json
{
  "viewName": "article_viewer",
  "params": {
    "category": "bookkeeping",
    "article": "cleanup_workflow"
  },
  "timestamp": 1779057304423
}
```

### 4.2 Lifecycle Flow Diagram
```mermaid
graph TD
    A[User Opens Help Center] --> B{Does help_center_last_view exist?}
    B -- No --> C[Load Default View 'help']
    B -- Yes --> D[Parse JSON Stored Payload]
    D --> E{Has state expired > 30 minutes?}
    E -- Yes --> F[sessionStorage.removeItem]
    F --> C
    E -- No --> G[loadView stored.viewName, stored.params]
```

### 4.3 30-Minute Auto-Expiry Protocol
State is validated upon module initialization inside `index.php` using an isolated recovery loop:
```javascript
// System: Subroute Recovery (Restore last page visited if active/under 30 minutes)
(function () {
    const storedStr = sessionStorage.getItem('help_center_last_view');
    if (storedStr) {
        try {
            const stored = JSON.parse(storedStr);
            const ageMinutes = (Date.now() - stored.timestamp) / 1000 / 60;
            if (ageMinutes < 30) {
                window.helpCenterApp.loadView(stored.viewName, stored.params);
                return;
            }
        } catch (e) {
            // Fall back to main hub on corrupted payloads
        }
        sessionStorage.removeItem('help_center_last_view');
    }
    window.helpCenterApp.loadView('help');
})();
```

* **Mitigation**: The 30-minute expiry enforces security by ensuring stale session settings or old navigations from previous work days are never forcefully rehydrated.

## 5. Core Dispatcher & Protected Routes (`router.php`)

To protect the Zero-Knowledge architecture, the application utilizes `router.php` as the primary request dispatcher for the built-in development server.

### 5.1 Directory Protection (403 Forbidden)
Direct browser URL access to sensitive backend directories is strictly hard-blocked. A **403 Forbidden** is immediately returned for:
- `/config/` (contains Master Salts and encrypted DEKs)
- `/databases/` (contains encrypted SQLCipher SQLite files)
- `/ai_persistent_files/` (internal project memory)
- `/php/` (portable server binaries)

### 5.2 API Interception (401 Unauthorized)
If a user attempts to fetch or navigate dynamically without the `db_key` cookie, the backend (`server/db.php`) intercepts the request and issues a `401 Unauthorized`. The core SPA router (`app.js`) intercepts this HTTP code globally and executes a `window.location.reload()`, gracefully clearing the active DOM and dropping the user back to the vault login shell.

---

```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
```
