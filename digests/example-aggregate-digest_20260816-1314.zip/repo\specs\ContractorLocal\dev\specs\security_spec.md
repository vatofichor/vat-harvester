# ContractorLocal - Security Architecture & Credentialing Specification

## 1. Overview
This document outlines the security architecture and credentialing flow for the ContractorLocal application, specifically detailing the Zero-Knowledge Vault implementation, Database Encryption (SQLCipher), and session management.

## 2. Threat Model & Mitigations
ContractorLocal is designed to run locally (e.g., via `localhost`), meaning traditional network interception (Man-in-the-Middle) is not the primary threat vector. The primary threat models are:
- **Physical Device Compromise**: Mitigated by AES-256 Full Database Encryption (SQLCipher). Without the Master Password, the databases cannot be read from the filesystem.
- **Cross-Site Scripting (XSS)**: Mitigated by storing the Data Encryption Key (DEK) exclusively in an `HttpOnly` session cookie, ensuring injected malicious scripts cannot exfiltrate the raw database key.
- **Lost Master Password**: Mitigated by a one-time generated Recovery Phrase, mathematically linked to the DEK via a separate Key Encryption Key (KEK).

## 3. Cryptographic Implementation (Zero-Knowledge Architecture)

### 3.1 Key Derivation Flow
1. **Master Password**: Provided by the user during Vault Setup.
2. **Master Salt**: A cryptographically secure random string generated upon setup and stored in `config/master.json`.
3. **Key Encryption Key (KEK)**: Derived from the `Master Password` + `Master Salt` using Argon2 (or equivalent key derivation function configured in `server/crypto.php`).
4. **Data Encryption Key (DEK)**: A purely random 256-bit (64 hex character) key generated once upon setup. This is the actual key that unlocks the SQLCipher databases.
5. **Encrypted DEK**: The DEK is encrypted using the derived KEK. Only the `Encrypted DEK` is stored on disk in `config/master.json`. The application has *zero knowledge* of the actual Master Password or the raw DEK at rest.

### 3.2 Recovery Implementation
During setup, a similar parallel process occurs for recovery:
1. **Recovery Phrase**: A human-readable multi-word phrase generated and shown to the user once.
2. **Recovery Salt**: Generated and stored in `master.json`.
3. **Recovery Encryption Key (REK)**: Derived from the `Recovery Phrase` + `Recovery Salt`.
4. **Recovery Encrypted DEK**: The same pure DEK is encrypted a second time using the REK and stored in `master.json`. This allows decrypting the DEK independently if the Master Password is forgotten.

## 4. Session & Credential Handling (HttpOnly Cookies)

### 4.1 Authentication (Login)
1. The user enters their Master Password in the UI.
2. An API request is sent to `server/auth.php?action=login`.
3. PHP derives the KEK, decrypts the DEK from `master.json`, and verifies success.
4. **Crucial Security Measure**: PHP sets the raw DEK into an `HttpOnly` cookie (`db_key`). This cookie cannot be accessed via `document.cookie` or `sessionStorage` in JavaScript, fully isolating the key from client-side execution contexts.
5. PHP returns a simple `{"success": true}`. The client sets a dummy `sessionStorage.setItem('logged_in', '1')` purely for UI state management.

### 4.2 API Requests
All subsequent data fetches (via `secureFetch` in `app.js`) utilize `credentials: 'same-origin'`. The browser automatically attaches the `HttpOnly` cookie containing the DEK to the request. 

### 4.3 Database Access (`server/db.php`)
1. The PHP script intercepts the `db_key` from `$_COOKIE['db_key']`.
2. **Error Trace Locking**: Before any decryption happens, PHP is commanded to explicitly disable error output (`ini_set('display_errors', 0)`) to prevent stack trace leaks of the key during crash dumps.
3. **Sanitization**: The key undergoes strict regex validation (`/^[a-f0-9]{64}$/i`) to ensure it is exactly a 256-bit hex string. This absolutely prevents any SQL injection into the subsequent `PRAGMA` call.
4. The key is injected into the SQLite connection: `PRAGMA key = '<DEK>';`.
5. **RAM Sanitization (Zeroing)**: Immediately following the `PRAGMA` execution, the PHP variable `$key` is overwritten with 64 zeroes (`str_repeat('0', 64)`) and `$_COOKIE['db_key']` is `unset()` to eagerly purge the unencrypted DEK from volatile RAM memory before continuing execution.
6. If the key is invalid, SQLCipher prevents reads, throwing an exception, which gracefully returns a `500 Database access denied` error.

## 5. Logout & Session Termination
When the user locks the vault:
1. A POST request is made to `server/auth.php?action=logout`.
2. The server forcefully invalidates the `db_key` cookie by setting its expiration to the past.
3. The client clears the `logged_in` UI flag and reloads the application shell, purging all decrypted data from the active DOM and memory.

### 5.1 Subroute State Timers
To prevent stale navigation state from surviving across distinct user sessions, sticky state parameters (such as the Help Center's active subroutes) are stored with a strict **30-minute auto-expiry timestamp**. If a session is abandoned, navigating back to the module drops the payload and enforces a clean index to protect session context.



## 6. Cryptographic Environmental Safeties (Fail-Closed Boot)
ContractorLocal runs on a bundled/portable PHP environment. If the underlying host environment lacks critical binary extensions, silent cryptographic weakening (like falling back to insecure hashes) could occur.
- **Dependency Assertions**: Upon boot (`server/crypto.php`), the system strictly evaluates if `openssl`, `pdo_sqlite`, and `hash` extensions are loaded into memory.
- **Hard-Lock**: If any required cryptographic extension is missing, the system aborts execution (`exit`), yields a `500 Internal Server Error`, and paints a terminal diagnostic view indicating exactly which module must be enabled. This completely blocks vault setup and unlocking to prevent catastrophic data loss or weak vault generation.

## 7. Development & Operations Security Notes
- Never print or log `$_COOKIE['db_key']` in error traces.
- Ensure the `databases/` and `config/` directories are explicitly excluded from version control (`.gitignore`).
- Any new PHP scripts establishing database connections MUST use `getDB()` in `server/db.php` rather than creating raw PDO instances to maintain the centralized security perimeter.
