# ContractorLocal - User Space Storage Audit Specification

## 1. Executive Summary
This document maps out all client-side browser storage (Cookies, `sessionStorage`, `localStorage`) and module-level filesystem storage utilized by the ContractorLocal application. This mapping ensures compliance with the Zero-Knowledge architecture and verifies that sensitive cryptographic keys, dynamic subroute states, and local documents are stored in secure, well-defined boundaries.

---

## 2. Browser Storage Mapping

### 2.1 Local Storage (`localStorage`)
- **Status:** **NOT UTILIZED**
- **Analysis:** The application strictly avoids persistent, across-session storage in the browser. No data, tokens, or states are saved to `localStorage` to prevent local data persistence after the vault is locked.

### 2.2 Session Storage (`sessionStorage`)
- **Status:** **UTILIZED (Benign State Tracking)**
- **File References:** `assets/js/app.js`, `modules/help-center/index.php`
- **Key(s) Utilized:**
  - **`logged_in`**
    - **Value:** `'1'`
    - **Purpose:** Acts as a benign boolean flag for the client-side SPA router (`app.js`). If present, the client renders the Main Vault Shell. If absent, it displays the login/setup flows.
    - **Security Posture:** Benign. Contains no cryptographic material or user data. Attacker spoofing attempts will trigger UI changes but fail all backend API operations with a `401 Unauthorized` due to the lack of actual decryption credentials.
    - **Lifecycle:** Created upon successful vault unlock. Destroyed explicitly when clicking "Lock Vault" or closing the browser session.
  - **`help_center_last_view`**
    - **Value:** Serialized JSON payload containing `viewName`, query `params`, and a `timestamp`.
    - **Purpose:** Restores the exact active subroute (article viewer or category topic) when the user returns to the **Help Center** after navigating to other modules.
    - **Security Posture:** Safe. Contains only public category and article slugs (e.g., `category: "bookkeeping"`, `article: "cleanup_workflow"`). No user data or database fragments are ever written here.
    - **Lifecycle & Expiry:** Enforces a strict **30-minute auto-expiry** protocol. Upon reloading the module, if the timestamp exceeds 30 minutes, the entry is deleted and the client falls back to the clean categories hub index.

### 2.3 HTTP Cookies
- **Status:** **UTILIZED (Strictly HttpOnly)**
- **File References:** `server/auth.php`, `server/db.php`, `server/manifest.php`
- **Key(s) Utilized:**
  - **`db_key`**
    - **Value:** 64-character hexadecimal string representing the derived SQLCipher Data Encryption Key (DEK).
    - **Attributes:** `Path=/`, `Session` (Expires: 0), `Secure=false` (Localhost operation), **`HttpOnly=true`**.
    - **Purpose:** Transmits the SQLCipher decryption key from the client to the PHP backend automatically on every dynamic API query.
    - **Security Posture:** Secure. Because `HttpOnly=true` is set, client-side JavaScript execution (such as XSS payloads) cannot access or read the cookie value.
    - **Lifecycle:** Established upon valid Master Password unlocking. Destroyed explicitly during logout by setting the expiration date to the past (`time() - 3600`).

---

## 3. Filesystem Storage Mapping (Copy-Center Module)

ContractorLocal implements a robust **Filesystem-First Document Vault** within the **Copy-Center** module. Rather than writing dynamic forms and document trees to standard database rows, documents are organized hierarchically on the server filesystem.

### 3.1 Directory Topology
Shared documents and dynamic records are isolated by CRM Client ID directories located at:
`/shared/client_docs/<client_id>/`
* **Security Isolation**: Path parsing is strictly regex-sanitized via `preg_replace('/[^a-zA-Z0-9_-]/', '', ...)` prior to execution, preventing Directory Traversal attacks (e.g. `../` injection).

### 3.2 Dynamic JSON Payload Storage (HTML Forms)
Documents filled or generated inside the HTML form builder are stored as serialized JSON files (`<form_name>_<control_number>.json`).

#### 3.2.1 Active Drafts & Versioning Metadata
Drafts capture dynamic input values without capturing structural templates. They store baked-in version data to track compatibility:
```json
{
  "meta": {
    "form_version": "1.0.0",
    "baked_version": "1.0.0"
  },
  "form_data": {
    "fullname": "Sebastian Mass",
    "phone": "+1 6162018409"
  }
}
```

#### 3.2.2 Committed & Signed Records (Hard-Locking)
When a document is signed and committed, the payload is locked by generating immutable signature blocks inside the metadata:
```json
{
  "meta": {
    "signature_hash": "64-character sha256 hex string",
    "signature_timestamp": "2026-05-17T22:30:53Z"
  },
  "form_data": { ... }
}
```
* **Read-Only Enforcer**: The backend API and frontend form editor inspect this `signature_hash`. If populated, all write permissions are hard-locked, disabling all input tags and rendering the document permanently read-only.

### 3.3 Raw Binary Storage (Uploaded PDFs)
Completed, signed, or external agreements are stored as raw PDF files (`*.pdf`) inside the client directory, retrieved directly by the browser's native PDF viewing engine using targeted streaming endpoints (`pdf_manager.php`).

---

## 4. Auditor Conclusion
ContractorLocal maintains a highly compliant **Zero-Knowledge client architecture**. Sensitive cryptographic secrets are shielded inside isolated `HttpOnly` transport blocks, browser-level cache persists strictly in ephemeral, short-lived states with validation limits (under 30 minutes), and user data is safely partitioned on-disk under strict sanitization and read-only signatures.

---



```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
```
