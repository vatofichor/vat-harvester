# ContractorLocal - Time, Jobs, & Activity Operational Specification
*A high-density operational reference manual detailing time tracking, project jobs, and activity checklists.*

---

## 1. Overview
The ContractorLocal platform manages operational tasks under the **Operations Sector** (backed by the conjoined `operations.sqlite` database). Three core modules run within this space:
1. **Time Tracker** (`time-tracker`): For clocking in/out, managing billable/non-billable hours, and mapping tasks to specific time blocks.
2. **Job Hub** (`job-hub` / `sync-hub`): For defining discrete project contracts, durations, and vendor mappings.
3. **Activity Logger** (`activity-logger`): For creating structured action items, task lists, and procedures.

These operational records sync to the **Finance Sector** (`sync_finance.sqlite` database) via the Sync-Hub to serve as staged inputs for the **Billing Center** invoicing workflow.

---

## 2. Time Tracker (`time-tracker`)
The Time Tracker captures actual hours worked. It is organized into **Work Periods** which contain multiple chronological clock entries (punches).

### 2.1 Work Periods
- **Properties**: Each Work Period has a title, is bound to a CRM Client, has a status ("Open" or "Closed"), and can be toggled as **Billable** or **Non-Billable**.
- **Non-Billable Override**: Setting a period to non-billable allows the hours to be tracked and closed on invoices, but forces a billing rate of $0.00.
- **Punches**: Punches are linear events labeled `IN` or `OUT` with an exact timestamp.
- **Auto-Correction Engine**: If a user double-clocks `IN` or double-clocks `OUT`, the system automatically inserts a soft `Missing` punch (offset by 1 second) to maintain chronological consistency and alerts the user to fix it.

### 2.2 Chronological Validation Rules for Editing
Users can manually adjust timestamps by clicking **Edit** next to any punch. To prevent timeline corruption, the following validation rules apply:
1. **Chronological Boundary Enforcement**:
   - If the edited punch is the **first** entry in the period: it cannot have a timestamp *later* than the second punch.
   - If the edited punch is the **last** entry in the period: it cannot have a timestamp *earlier* than the second-to-last punch.
   - If the edited punch lies in the **middle**: it must fall strictly between the preceding punch's timestamp and the succeeding punch's timestamp.
2. **Failure Resolution**: If an edit breaks these rules, the system rejects the input at the UI level, alerts the user, and blocks database persistence on the backend.

---

## 3. Job Hub & Project Tracking (`job-hub`)
The Job Hub registers specific contract projects.
- **Structure**: Each job has a name (e.g. "Install Underlayment"), start date, end date, client ID, and vendor ID.
- **Relationship to Time**: Work Periods in the Time Tracker can be attached to jobs. This links logged time blocks directly to project scopes.
- **Job Exclusivity**: A job can only be attached to one active Work Period at a time. Once attached, it is sidelined from selection elsewhere.

---

## 4. Activity Logger (`activity-logger`)
The Activity Logger manages linear task lists and compliance checklists.
- **Structure**: A list consists of a title (e.g., "Roof Tear Off") and a set of ordered task descriptions.
- **Status**: Lists can be toggled as **Open** or **Closed**.
- **Attachment to Time**: Activity Lists can be attached to Time Tracker Work Periods. Individual IN punches inside that period can then be mapped to specific tasks on the list, indicating exactly what work was performed during that shift.

---

## 5. The Staging & Invoicing Cross-Boundary Loop
The Sync-Hub bridges these operational details into the Billing Center for invoicing.

```mermaid
graph TD
    A[Time Tracker / Activity Logger] -->|Commit to Sync-Hub| B(Staging Tables: sync_invoicable_time / sync_activity_lists)
    B -->|Staged Queue| C[Billing Center Import Mapper]
    C -->|Map Data| D[Invoice Document Textarea]
    D -->|Auto-Close Call| E[Set is_closed = 1 on Staging Tables]
    E -->|Removed from Queue| B
```

### 5.1 Committing to Sync-Hub
When work on a Work Period or Activity List is completed, the user commits it to the Sync-Hub. This action duplicates the operational metadata into the `sync_invoicable_time` and `sync_activity_lists` staging tables.

### 5.2 Billing Import & Automatic Staged Closure
1. **Visual Import Drawer**: When editing an invoice in the Billing Center, a drawer lists all staged time cards and activity lists for that client.
2. **Visual Mapping**: The user selects a target textarea field and clicks **Map Data** on a staged item. The details are parsed and appended to the textarea.
3. **Automatic Closure**: Immediately upon mapping, a request is dispatched to set `is_closed = 1` for the staged record in the Sync-Hub database. The item instantly disappears from the available import queue to prevent duplicate invoicing.
4. **Reopening and Re-staging**: If a document is deleted or the billing draft is discarded, the only way to re-bill those hours is to:
   - Navigate back to the Time Tracker (or Activity Logger).
   - Uncheck the "Closed" status flag on the Work Period (or Activity List).
   - Re-commit the period (or list) to the Sync-Hub, which resets `is_closed = 0` on the staging queue.

---

#&nbsp;Copyright (c) 2026:
#&nbsp;vatofichor&nbsp;-&nbsp;Sebastian Mass&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[&gt;_&lt;]
#&nbsp;&amp;&nbsp;Assisted By Gemini Antigravity&nbsp;/|\  
