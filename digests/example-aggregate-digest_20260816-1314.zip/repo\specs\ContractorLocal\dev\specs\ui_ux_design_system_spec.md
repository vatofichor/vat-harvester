# UI/UX Design System Specification
**Project**: ContractorLocal
**Aesthetic Profile**: "Old School Premium" (Windows XP / Classic Mac blend)

---

## 1. Overview & Core Philosophy
The visual language of ContractorLocal is intentionally designed to evoke the tactile, high-density, no-nonsense utility of classic desktop operating systems (e.g., Windows XP, Classic Mac OS) while maintaining a modern, premium dark-mode aesthetic. 

**Guiding Principles:**
- **No Fluff, Pure Utility**: No distracting animations, no modals, no pop-ups, and no out-of-flow DOM elements. Every element is a tool or a grid row.
- **High-Density Grid**: Screen real estate is maximized for data legibility and input speed over spacious modern web trends.
- **Single Source of Action**: A strict "page-per-form" and "one purpose per action" mentality. Clicking an action fully transitions the workspace context rather than popping open a floating dialog.
- **Tactile Feedback**: Elements must feel "physical" to click, utilizing border shading to create inset/outset 3D depth.

---

## 2. Color Palette & Typography

### 2.1 Color Tokens
The system primarily utilizes a cool, dark-blue slate palette optimized for low eye strain during long data-entry sessions.

*   **`--bg-desktop`**: `#2c3e50` — The deep slate backdrop of the main application shell.
*   **`--bg-window`**: `#34495e` — The primary background for active tool windows and content areas.
*   **`--border-light`**: `#5d6d7e` — Used for top/left highlights to create physical component depth.
*   **`--border-dark`**: `#212f3d` — Used for bottom/right shadows to anchor components.
*   **`--text-main`**: `#ecf0f1` — Off-white primary text for high contrast without the glare of pure white.
*   **`--title-bg`**: `#2980b9` — The classic blue "Window Title Bar" header background.
*   **`--input-bg`**: `#1c2833` — A very dark inset background for input fields, creating a recessed "well" effect.
*   **`--btn-bg`**: `#3498db` — The primary action blue.
*   **`--btn-hover`**: `#2980b9` — Active/Hover state blue.
*   **Dev/Test Action ("Fire" Color)**: `#e65100` / `#d84315` — Reserved strictly for development/testing data injection buttons to visually isolate them from production actions.

### 2.2 Typography
- **UI Elements**: `Tahoma`, `Segoe UI`, `sans-serif`. Chosen for their exceptional legibility in dense tables and nostalgic desktop application feel.
- **Data Inputs**: `monospace`. All form fields (`input[type="text"]`, `input[type="password"]`) utilize monospace fonts to align decimal points, hashes, and financial data perfectly.

---

## 3. Component Architecture

### 3.1 The "Window Shell"
Instead of floating cards, primary UI boundaries are drawn using rigid, bordered window boxes.
- **Structure**: A `.window` container with a distinct `.window-title` bar at the top, mimicking OS-level software.
- **Depth**: The container uses a `2px` solid border, utilizing `--border-light` and `--border-dark` to create a slight embossed extrusion, supplemented by a hard `box-shadow: 4px 4px 10px rgba(0,0,0,0.5);`.

### 3.2 Navigation
Sidebar navigation (`.nav-item`) acts as tactile hardware buttons rather than simple web links.
- **Default**: Raised appearance with `--input-bg`.
- **Hover/Active**: Inverts colors, fills with `--btn-bg`, and utilizes a `1px inset` border to physically "press" into the screen when clicked.

---

## 4. Interaction & State Management

### 4.1 Tactile Buttons (Pseudo-3D)
Buttons do not scale or fade smoothly on click. They instantly snap.
- **Default State**: Outset borders (Light top/left, Dark bottom/right).
- **Active (Click) State**: The borders invert (Dark top/left, Light bottom/right) and the background darkens to `--btn-hover`. This produces a satisfying, instantaneous mechanical "click" feedback.

### 4.2 Error Handling
- Errors are displayed in-flow (never in alerts or modals) using a high-contrast red (`#e74c3c`), strictly bolded, and centered above or below the offending action.

---

## 5. Form Mentality: One Purpose Per Action
The architecture strictly bans multi-step wizards or overlapping modals.
1.  **Isolation**: If a user needs to upload a document, the entire workspace transitions to the Document Upload Tool (`import.php`).
2.  **Focus**: The tool contains exactly what is needed for that specific action (Client Select -> File Select -> Upload) and nothing else.
3.  **Escape Route**: Every isolated tool view MUST feature a `.btn-secondary` back button (e.g., `← Back to Catalog`) prominently at the top left to instantly return the user to the parent hub.

---

## 6. The Sebastian Clause (Branding & Attribution)
To ensure the lineage and branding of the software remain intact—especially during potential future closed-source or SaaS spinoffs—the system enforces the following global UI requirement:

*   **The Clause**: The global `footer.php` attribution stating **"A product by sebastianmass.com"** MUST remain visible and unobscured across all onboarding routes, setup screens, and primary unauthenticated entry points.

---



```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
```
