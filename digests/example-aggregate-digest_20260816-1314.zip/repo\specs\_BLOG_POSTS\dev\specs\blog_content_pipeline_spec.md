# Blog Content Pipeline: Architecture Specification
> **Spec Version**: 1.0  
> **Author**: vatofichor — Sebastian Mass  
> **Date**: 2026-07-04  
> **Scope**: Platform-agnostic content management architecture for blog authoring, staging, version control, and publishing.  
> **Classification**: Reusable Specification — NOT bound to a specific project implementation.

---

## 1. Purpose & Design Intent

This specification defines the **structural architecture** of a blog content pipeline: how articles are authored, staged, tracked, edited, and published. It is intentionally **non-specific** to any particular tech stack, blog platform, or deployment target. The architecture described here is a template that any implementation can inherit.

The system solves three problems:
1. **Content Drift** — articles edited across sessions without version history lose editorial intent.
2. **Pipeline Opacity** — without defined staging areas, the state of any given article is ambiguous.
3. **Format Fragmentation** — without a rules file and bootstrapped templates, articles diverge in structure, class usage, and metadata shape.

---

## 2. Directory Architecture

### 2.1 The Content Root

The content root is a single directory (anonymized here as `_CONTENT_ROOT`) that contains the entire blog pipeline. Every subdirectory and file within this root has a defined role.

```
_CONTENT_ROOT/
│
├── blog-rules.txt              # [PERMANENT] HIL instruction file
├── blog-style.css              # [PERMANENT] Shared override stylesheet
│
├── <category-or-topic-a>/      # Root-level topic/project folder
├── <category-or-topic-b>/      # Root-level topic/project folder
├── .../                        # As many as needed
│
├── WIP/                        # Conversion workspace: MD → HTML partfile
│
└── _PUBLISHED/                 # Versioned archive of finalized articles
    ├── v1/                     # Publishing batch 1
    │   ├── Article-Title.html  # Finalized HTML partfile
    │   └── ...
    ├── v2/                     # Publishing batch 2
    └── vN/                     # Future batches (pre-created or on-demand)
```

### 2.2 Root-Level Topic Folders

Articles arrive into this workspace however they get here. Once inside, they are sorted into **root-level folders** by category, topic, project, or any grouping the HIL chooses. There is no prescribed internal structure within these folders. What goes on inside is entirely up to the HIL.

These folders are the drafting and staging ground. Their contents may be markdown, HTML, scratch notes, assets, or nothing at all (empty placeholders for future topics).

### 2.3 Upstream Flow (System-Prompt Scope, Not Blog-Rules)

The broader authoring system defines an upstream pipeline for how content reaches this workspace:

| Stage | Location | Scope |
|---|---|---|
| `/posts/` | Source authoring space | System prompt |
| `/posts/staged/` | Staged drafts promoted for transfer | System prompt |
| `_CONTENT_ROOT/` | This workspace; receives staged content | This spec |

The `posts/` and `posts/staged/` directories belong to the **system prompt** that governs the broader development workflow. They are NOT part of `blog-rules.txt` and are NOT defined within this specification. This spec picks up where that upstream flow ends: content arrives here, gets sorted into root-level topic folders, and enters the conversion pipeline.

### 2.4 Directory Role Definitions

| Directory | Lifecycle Stage | Mutability | Owner |
|---|---|---|---|
| `<topic>/` (root-level) | **Drafting/Staging** — content sorted by category | Fully mutable; internal structure is HIL-defined | HIL |
| `WIP/` | **Conversion** — active HTML partfile assembly, annotation resolution | Fully mutable | AI + HIL |
| `_PUBLISHED/vN/` | **Archive** — immutable published snapshots | Append-only per batch; edits create new versions | HIL (publish gate) |

### 2.5 Lifecycle Flow (Within This Workspace)

```
         ┌─────────────┐
         │  <topic>/    │   Content arrives, sorted by HIL.
         │  (root)      │   Internal structure is freeform.
         └──────┬──────┘
                │  HIL moves draft to WIP for conversion
                ▼
         ┌─────────────┐
         │    WIP/      │   MD → HTML partfile conversion.
         │              │   blog-rules.txt applied. Style injected.
         └──────┬──────┘
                │  Final QA pass. HIL sign-off.
                ▼
         ┌─────────────┐
         │ _PUBLISHED/  │   Finalized HTML partfile archived.
         │ vN/          │   Version batch sealed.
         └─────────────┘
```

---

## 3. The Rules File (`blog-rules.txt`)

The rules file is a **permanent, root-level instruction document** that defines every structural, stylistic, and editorial constraint for article production. It is injected into every editing session (human or AI-assisted) as the authoritative reference.

### 3.1 Required Sections

A complete `blog-rules.txt` MUST contain the following sections:

#### 3.1.1 Authorship & Publishing Metadata

```
# Authorship & Publishing Metadata

Owner:                  [Legal name of content owner]
Authoring:              [Primary author name]
Alternate Title:        [Pseudonym, handle, or platform identity]
Primary Model:          [AI model identifier, if AI-assisted]

## Authoring Line Format
Published by [author:usertag][author:name], Authored by <Author|Model> | <Month Day, Year>

## Publishing Markers
<!-- PUBLISHED ON MM/DD/YY @ HH:MM[A/P] -->
<!-- HIL LEFTOFF -->

## HIL Inline Annotations (Editorial Notes)

During drafting and review, the HIL uses inline annotations to communicate
editorial intent, corrections, and contextual direction directly inside the
working document. These annotations are **first-class elements** of the
pipeline — they are never decorative. They represent active editorial
instructions that MUST be resolved before an article advances past WIP.

### Markdown Draft Format
> HIL NOTE: <editorial instruction or contextual correction>

Placed immediately below the paragraph, bullet, or section they address.
They are blockquote-prefixed to visually separate them from article content.

### HTML Partfile Format
<!-- HIL NOTE: <editorial instruction or contextual correction> -->

Used in the same positional manner inside HTML partfiles during WIP
conversion. Placed as a comment node directly after the element they address.

### Examples

Markdown (in posts/<topic>/draft.md or WIP/*.md):
```markdown
- **Tree-Based Permission Access**: Access controls map naturally
  to filesystem permission patterns.
> HIL NOTE: we aren't literally saying use a filesystem. reframe
> this around the desktop-experience alignment pattern for agents.

### The Unified Interface
> HIL NOTE: this isn't just for design businesses — rewrite to
> target ALL systems and projects as AI becomes standard.
```

HTML (in WIP/*.html):
```html
<p class="blog-p">State coordination uses ShadowDOM diff tracking.</p>
<!-- HIL NOTE: wrong reference. link to sebastianmass.com/github
     reflexive-dom-framework instead. -->
```

### Resolution Rules
1. Every `HIL NOTE` must be addressed (content edited, rewritten, or
   removed per the instruction) before the article exits WIP.
2. Resolved notes are deleted entirely — they do not persist into
   _PUBLISHED/ versions.
3. If a note cannot be resolved without HIL clarification, the article
   remains in WIP until the HIL responds.
4. AI editors must NEVER silently ignore or skip a HIL NOTE. If the
   instruction is ambiguous, flag it and halt.
```

Purpose: Standardizes how authorship is declared in every article, defines the exact HTML structure of the publishing line, and establishes comment markers for editorial state tracking.

**Placeholders for Future Metadata**:
```
## Future Metadata Fields (Reserved)
# Revision-ID:         [auto-generated hash or sequential ID]
# Review-Status:       [DRAFT | STAGED | REVIEW | PUBLISHED | AMENDED]
# Canonical-URL:       [permalink on publishing platform]
# Tags:                [comma-separated topic tags]
# Series:              [series name if part of a multi-post series]
# Reading-Time:        [estimated minutes]
```

These fields are defined but not yet populated. They establish forward-compatible schema for when the pipeline introduces automated metadata extraction or CMS integration.

---

#### 3.1.2 Style Guide & Class Vocabulary

```
# Style Guide

## Custom CSS Classes (Override Vocabulary)

.blog-p              Paragraph spacing override (margin-top, line-height)
.blog-li             List item spacing override
.blog-h2, .blog-h3  Heading spacing overrides (margin-top, margin-bottom)
.blog-h4             Sub-heading spacing override
.demi-bold           Inline keyword emphasis (bolder weight, accent color)
.blog-toast          Blockquote styled as persistent-toast callout
.blog-blockquote     Heavy left-border pull quote
.post-meta           Authoring/date line container
.post-content        Body content wrapper
.blog-footer         Article footer container
.blog-edit-date      Edit timestamp span inside footer
```

Purpose: Defines the complete class vocabulary. Any class not listed here is unauthorized. This prevents class sprawl and ensures every article uses a shared, predictable styling surface.

---

#### 3.1.3 Bootstrapped HTML Templates

The rules file must include **copy-paste-ready HTML scaffolds** for article creation:

```
# Bootstrapped Templates

## Minimal Article Scaffold
```

```html
<article data-order="N">
  <style>
    /* Contents of blog-style.css injected here */
  </style>

  <h1>Article Title</h1>

  <div class="post-meta">
    Published by [author:usertag][author:name],
    Authored by <Author|Model> | <Month Day, Year>
  </div>

  <div class="post-content">
    <p class="blog-p">Opening paragraph.</p>

    <h2 class="blog-h2">Section Heading</h2>
    <p class="blog-p">Section content with
      <span class="demi-bold">emphasized keyword</span>
      inline.
    </p>

    <blockquote class="blog-toast">
      Callout or aside message styled as a toast.
    </blockquote>

    <ul>
      <li class="blog-li">List item with spacing override.</li>
    </ul>
  </div>

  <!-- Optional footer -->
  <div class="blog-footer">
    <span class="blog-edit-date">Last Edited: July 4, 2026</span>
  </div>
</article>
```

```
## Empty Scaffold (Blank Start)
```

```html
<article data-order="N">
  <style></style>
  <h1></h1>
  <div class="post-meta"></div>
  <div class="post-content"></div>
</article>
```

Purpose: Eliminates structural guesswork. Every new article starts from one of these scaffolds, guaranteeing consistent DOM shape across the entire blog.

---

#### 3.1.4 Hard Asset & Library Links

```
# Hard Assets & References

## Stylesheet
Path: <CONTENT_ROOT>/blog-style.css
Usage: Injected as <style> tag content inside every <article> element.
       NOT linked externally. Embedded per-article for platform isolation.

## UI/UX Specification
Path: <SPECS_ROOT>/design-specs/<spec-name>/
File: design-spec.md
Usage: Read for typography rules, color tokens, sizing constraints,
       and interaction targets. Morph into blog-style.css as needed.

## Asset Storage
Path: posts/<topic>/assets/
Usage: Topic-specific images, diagrams, screenshots.
       Referenced via relative paths in markdown drafts.
       Converted to absolute or CDN paths during HTML conversion.

## External Libraries
Policy: NONE. Articles are zero-dependency HTML fragments.
        No JavaScript libraries. No CSS frameworks.
        All styling is self-contained in the embedded <style> tag.
```

Purpose: Declares where every hard dependency lives and makes the zero-dependency policy explicit. The design-spec link ensures visual alignment without coupling articles to a framework.

---

#### 3.1.5 Constraints & Anti-Patterns

This section defines what is **forbidden** without revealing implementation details of the publishing platform.

```
# Constraints & Anti-Patterns

## Typography
- NEVER use emdashes (—, –, or any variant). Use commas, colons,
  semicolons, or parentheses as alternatives.
- NEVER use curly/smart quotes. Straight quotes only.
- Headings follow strict hierarchy: one H1 per article, then H2 → H3 → H4.
  Never skip levels.

## Structural
- NEVER apply inline styles. All styling flows through blog-style.css classes.
- NEVER use <div> without a defined class from the Style Guide vocabulary.
- NEVER nest articles or use <article> inside <article>.
- NEVER use <script> tags. Articles are static HTML fragments.
- NEVER include external stylesheet <link> tags. The <style> tag is embedded.

## Editorial
- NEVER publish without resolving ALL `> HIL NOTE:` (markdown) and
  `<!-- HIL NOTE: -->` (HTML) annotations. Every note is a hard gate.
  Unresolved notes block promotion from WIP to _PUBLISHED/.
- NEVER publish without the post-meta authoring line.
- NEVER silently discard, skip, or "resolve" a HIL NOTE by deleting it
  without applying the editorial instruction it contains.
- NEVER modify a published article in _PUBLISHED/ directly.
  Create an amended copy in WIP/, apply edits, re-publish to the next
  version batch, and add the Last Edited footer.
- NEVER use placeholder text ("Lorem ipsum", "TODO", "[INSERT]") in
  published output.

## Interactivity
- NEVER add hover effects, animations, transitions, or interactive elements.
- NEVER use forms, inputs, or buttons inside article content.
- Articles are plain-text-weight HTML. The platform handles interactivity.

## Platform Coupling
- NEVER reference the publishing platform by name in the rules file
  or in article content structure.
- NEVER assume platform-specific DOM wrappers. Articles must render
  correctly as standalone <article> fragments.
- NEVER hard-code platform CSS class names. Use only the blog-* vocabulary.
```

Purpose: Defines the negative space of the system. These rules are deliberately platform-agnostic so the pipeline can migrate between blog platforms without rewriting the constraint set. They constrain the **shape** of output without revealing **where** it deploys.

---

## 4. Version Control & Edit Tracking

### 4.1 Batch Versioning (`_PUBLISHED/vN/`)

Articles are not individually versioned. Instead, they are grouped into **publishing batches**:

| Batch | Semantic Meaning |
|---|---|
| `v1/` | Initial publication set |
| `v2/` | Second publication wave OR first round of amendments to v1 articles |
| `vN/` | Nth publishing event |

When an existing article is edited post-publication:
1. The original remains untouched in its `vN/` directory.
2. A working copy is placed in `WIP/` for editing.
3. The edited version is published to the **next sequential** `vN+1/` directory.
4. A `<!-- Last Edited: ... -->` footer is added to the new version.

This creates a **linear, append-only history** without requiring git or a database.

### 4.2 Edit Metadata

Every amended article must include:

```html
<div class="blog-footer">
  <span class="blog-edit-date">Last Edited: July 4, 2026 at 12:57 AM</span>
</div>
```

### 4.3 Future: Diff-Based Tracking (Reserved)

The architecture reserves space for a future diff-tracking layer:
```
_PUBLISHED/
├── v1/
│   └── Article-Title.html
├── v2/
│   └── Article-Title.html        ← amended version
├── .diffs/                        ← FUTURE: auto-generated diffs
│   └── Article-Title.v1-v2.diff   ← textual diff between versions
```

This is not yet implemented but the directory structure accommodates it without breaking changes.

---

## 5. The Stylesheet (`blog-style.css`)

### 5.1 Origin & Rationale

Blog platforms ship their own global CSS — typography, spacing, colors, component sizing — and that CSS is outside the author's control. It changes when the platform updates. It renders differently per theme. And critically, it applies indiscriminately to every element inside the article body, overriding the author's intended visual hierarchy.

To solve this, the HIL authored `blog-style.css` as a **single, standalone stylesheet** that serves as the global import for maintaining **post-level style rules**. Rather than fighting the platform's CSS cascade from the outside, this stylesheet is **embedded directly inside each article** as a `<style>` tag. Every published `<article>` element carries its own copy of these rules.

This design choice produces three guarantees:
1. **Platform Independence** — the article's visual identity survives platform CSS changes, theme swaps, and even full platform migrations. The styles travel with the content.
2. **Post-Level Control** — spacing, emphasis weight, callout formatting, and heading rhythm are defined at the article level, not inherited from a platform global. Each post renders exactly as authored.
3. **Zero External Dependencies** — no `<link>` tags, no CDN requests, no build step. The styles are inline-embedded and self-contained. If you copy the `<article>` HTML fragment into any blank page, it renders correctly.

### 5.2 How It Works

The HIL maintains `blog-style.css` as a **single source file** in the content root. During HTML partfile conversion (the WIP stage), the full contents of this file are copied into a `<style>` tag as the **first child element** of the `<article>`:

```html
<article data-order="N">
  <style>
    /* === Entire contents of blog-style.css pasted here === */
    :root {
      --primary-color: #FF6B35;
      --text-color: #333;
      --bg-color: #f5f5f5;
      --toast: #FFCC99;
      --demibold-text: #1e1d1d;
    }
    li.blog-li { margin-top: 15px; line-height: 1.7em; }
    p.blog-p   { margin-top: 15px; line-height: 1.7em; }
    /* ... remainder of class rules ... */
  </style>

  <h1>Article Title</h1>
  <!-- ... -->
</article>
```

The CSS file itself is never linked externally. It exists solely as the master copy from which every article's embedded `<style>` block is derived.

### 5.3 Architecture

The stylesheet is organized into three layers:

```css
/* === Layer 1: Design Tokens === */
/* CSS custom properties defining the color palette and visual identity. */
/* These are the ONLY values that change between design iterations. */
:root {
  --primary-color:    /* brand accent */;
  --text-color:       /* body text */;
  --bg-color:         /* content background */;
  --toast:            /* toast/callout border color */;
  --demibold-text:    /* emphasis text color */;
}

/* === Layer 2: Spacing Overrides === */
/* Platform CSS sets its own margins and line-heights on standard elements. */
/* These element-qualified classes reclaim control at the post level. */
li.blog-li    { /* list item spacing */ }
p.blog-p      { /* paragraph spacing */ }
h2.blog-h2,
h3.blog-h3,
h4.blog-h4    { /* heading spacing */ }

/* === Layer 3: Custom Components === */
/* Semantic components unique to the blog's visual language. */
blockquote.blog-toast      { /* italic callout with toast-colored border */ }
blockquote.blog-blockquote { /* heavy left-border pull quote */ }
span.demi-bold             { /* inline keyword emphasis (bolder + accent) */ }
```

### 5.4 Rules
- **Single source**: `blog-style.css` in the content root is the only place styles are defined. Articles never contain ad-hoc CSS additions inside their `<style>` tags.
- **Embed, never link**: The contents are always copied in, never referenced via `<link>`. This is the core of the platform-independence guarantee.
- **Element-qualified selectors**: Class selectors are always prefixed with their element type (`p.blog-p` not `.blog-p`) to avoid unintended inheritance from platform CSS that may share generic class names.
- **Token values live in CSS, not in the rules file**: `blog-rules.txt` defines the class vocabulary and constraints; `blog-style.css` defines the actual visual values. Separation of spec from config.
- **Size constraint**: The stylesheet must remain under 100 lines. If it grows beyond that, the design is overreaching — extract a secondary override sheet or simplify.
- **Sync discipline**: When `blog-style.css` is updated, previously published articles in `_PUBLISHED/` are NOT retroactively patched. They retain the stylesheet version they were published with. Only new or actively edited articles pick up the latest version during their WIP conversion pass.

---

## 6. Authorship & Identity System

### 6.1 The Authoring Line

Every article has exactly one authoring line as the second child of `<article>`:

```html
<div class="post-meta">
  Published by [usertag][name], Authored by <Author|Model> | <Date>
</div>
```

### 6.2 Authoring Scenarios

| Scenario | Format |
|---|---|
| AI-only authorship | `Authored by <Model Name>` |
| Human-only authorship | `Authored by <Human Name>` |
| Co-authored | `Authored by <Human Name> and <Model Name>` |
| Human-published, AI-authored | `Published by <Human>, Authored by <Model>` |

### 6.3 Signature Block

Every article file includes a copyright signature, either visible or as an HTML comment:

```html
<!--
# Copyright (c) <YEAR>:
# <handle> - <Legal Name>     [>_<]
# & Assisted By <Model>       \|\
-->
```

### 6.4 Future: Structured Authorship Metadata (Reserved)

```html
<!-- ARTICLE-META
  author:       "Name"
  co-author:    "Model"
  published:    "YYYY-MM-DD"
  last-edited:  ""
  revision:     "1"
  tags:         ""
  series:       ""
  canonical:    ""
-->
```

This structured comment block is reserved for future tooling that parses article metadata programmatically.

---

## 7. Applying This Specification

### 7.1 For a New Blog Implementation

1. Create the directory tree from Section 2.1.
2. Write a `blog-rules.txt` containing all sections from Section 3.
3. Create `blog-style.css` following the architecture in Section 5.
4. Populate the bootstrapped templates and begin drafting in `posts/`.

### 7.2 For AI-Assisted Editing Sessions

1. Inject `blog-rules.txt` into the session context.
2. Reference `blog-style.css` for class vocabulary.
3. Follow the lifecycle flow (Section 2.3) for all content operations.
4. Enforce all constraints from Section 3.1.5 without exception.

### 7.3 For Platform Migration

Because the specification is platform-agnostic:
1. The `_PUBLISHED/` archive transfers as-is (standalone HTML fragments).
2. `blog-style.css` tokens may need remapping to the new platform's variable scheme.
3. `blog-rules.txt` constraints remain valid regardless of platform.

---

## 8. Specification Boundary

This document defines **what** the pipeline looks like and **how** it behaves. It does NOT define:
- Which blog platform publishes the articles
- Which server or CDN hosts the content
- Which CMS or editor is used for writing
- Which AI model assists in drafting

Those decisions are implementation details belonging to the project that inherits this spec.

---

```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity \|\
```
