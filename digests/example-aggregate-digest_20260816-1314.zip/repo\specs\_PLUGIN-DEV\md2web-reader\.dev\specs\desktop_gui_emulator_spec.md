# Standalone Retro Desktop GUI Window Emulator Shell Specification

**Project:** md2web Reader Engine Architecture  
**Specification Target:** Reusable Standalone GUI Window Chassis & Theme Framework  
**Author:** vatofichor - Sebastian Mass & Gemini Antigravity  
**Date:** 2026-08-15  

---

## 1. Architectural Intent & Scope

This specification isolates the **Standalone Desktop GUI Window Emulator Shell** from project-specific routing, Markdown parsing, or server APIs. The goal is to provide a complete, framework-agnostic UI chassis—capturing classic retro-modern window bevels, window titlebars, window control buttons, inline option menus, resizable side drawers, statusbar cells, and theme engines—ready to be extracted and embedded into secondary web applications or tools.

```
+-----------------------------------------------------------------------------------+
| .retro-workspace (Desktop Viewport Wrapper)                                       |
|                                                                                   |
|  +-----------------------------------------------------------------------------+  |
|  | .window-container (Desktop Window Emulator Shell)                           |  |
|  | +-------------------------------------------------------------------------+ |  |
|  | | .window-titlebar (Icon, App Title, Titlebar Controls [🗖] [✕])           | |  |
|  | +-------------------------------------------------------------------------+ |  |
|  | | .window-menubar (Inline Dropdown Option Menus: File | View | Help...)  | |  |
|  | +------------------------------------+---+--------------------------------+ |  |
|  | | .sidebar-drawer                    |   | .viewer-panel                  | |  |
|  | | (Generic Pluggable Side Drawer)    | . | (Generic Client Viewport)      | |  |
|  | | - Header slot / Action buttons     | s | - Toolbar / Breadcrumbs slot   | |  |
|  | | - Content tree / Navigation mount   | z | - Main Content Viewport slot   | |  |
|  | +------------------------------------+---+--------------------------------+ |  |
|  | | .window-statusbar (3-Column Context Grid: Status | Theme | Version)     | |  |
|  | +-------------------------------------------------------------------------+ |  |
|  +-----------------------------------------------------------------------------+  |
+-----------------------------------------------------------------------------------+
```

---

## 2. Visual Design System & Bevel Geometry (`cleanx.css`)

The visual design system mimics classic Windows / NeXTSTEP high-density desktop GUI containers with crisp, non-fluff retro beveling.

### A. Border & Bevel Geometry
Bevel depth is achieved using asymmetric border colors:
- **Outset Bevel (Raised Containers & Buttons)**:
  - Top & Left borders: `--border-light` (light highlight edge).
  - Bottom & Right borders: `--border-dark` (dark shadow edge).
- **Inset Bevel (Pressed Buttons & Input Fields)**:
  - Top & Left borders: `--border-dark`.
  - Bottom & Right borders: `--border-light`.

```css
/* Standard Raised Retro Bevel Container */
.window-container {
    border-top: 2px solid var(--border-light);
    border-left: 2px solid var(--border-light);
    border-right: 2px solid var(--border-dark);
    border-bottom: 2px solid var(--border-dark);
    box-shadow: 5px 5px 15px rgba(0,0,0,0.3);
}

/* Retro Push Button Inset Active State */
.titlebar-btn:active, .drawer-action-btn:active, .dialog-btn:active {
    border-top: 1.5px solid var(--border-dark);
    border-left: 1.5px solid var(--border-dark);
    border-right: 1.5px solid var(--border-light);
    border-bottom: 1.5px solid var(--border-light);
    padding-top: 2px;
    padding-left: 2px;
}
```

### B. Dual Theme Tokens
The GUI emulator defaults to **Slate Dark Mode** with a built-in toggle for **Warm Cream Light Mode**.

| CSS Variable Token | Slate Dark Mode (Default) | Warm Cream Light Mode |
| :--- | :--- | :--- |
| `--bg-desktop` | `#1b1e23` (Dark Slate) | `#b9b29b` (Muted Warm Desktop) |
| `--bg-window` | `#2c313c` (Mid-tone Window Frame) | `#dfd9c6` (Classic Beige Window) |
| `--bg-client` | `#21252b` (Client Working Area) | `#faf8f2` (Manuscript Cream) |
| `--bg-field` | `#181a1f` (Sunken Field / Sidebar) | `#d3cbb3` (Sunken Field Background) |
| `--titlebar-bg-start` | `#3e4451` | `#8e8469` |
| `--titlebar-bg-end` | `#2c313c` | `#615a45` |
| `--titlebar-text` | `#ffffff` | `#ffffff` |
| `--border-light` | `#4b5263` | `#fefdfb` |
| `--border-dark` | `#181a1f` | `#8b8067` |

---

## 3. Window Layout Component Anatomy

### A. Title Bar & Controls (`.window-titlebar`)
Located at the top of `.window-container`. Height is defined by `--titlebar-height: 32px`.

```html
<div class="window-titlebar">
    <div class="titlebar-info">
        <span class="titlebar-icon">📖</span>
        <span class="titlebar-title">App Title - Standalone GUI Shell</span>
    </div>
    <div class="titlebar-controls">
        <button class="titlebar-btn" id="btn-toggle-viewport" title="Toggle Full Viewport Size">🗖</button>
        <button class="titlebar-btn titlebar-btn-close" id="btn-close-file" title="Close / Reset Document">✕</button>
    </div>
</div>
```

#### Window Control Buttons Mechanics
1. **Square Maximize Button (`🗖` / `🗗`)**:
   - **Maximize Action (`setViewportMode(true)`)**: Automatically collapses the side drawer (`setSidebarVisible(false)`) **before** applying `.viewport-mode` styling (`100vw × 100vh`, `0px` desktop padding, shadow removal, minimal top border). Swaps button symbol to `🗗`.
   - **Restore Action (`setViewportMode(false)`)**: Automatically re-opens the side drawer (`setSidebarVisible(true)`) **before** removing `.viewport-mode` styling, returning container to centered `1200px × 800px` framing. Swaps button symbol back to `🗖`.
   - **State Persistence**: Viewport mode preference is saved in `localStorage.setItem('md2web-viewport', 'true'|'false')`.
2. **Close Button (`✕`)**:
   - Triggers `closeFile()` / `showWelcome()` to reset the client viewport to initial state, un-highlight active items, and reset pushState history without deleting disk content. Features red hover highlight (`.titlebar-btn-close:hover { background-color: var(--accent-red); }`).

---

### B. Option Menus System (`.window-menubar`)
The menubar contains classic dropdown menus (`File`, `View`, `Help`) implemented with pure in-flow CSS overlay positioning— strictly eliminating modal popups.

```html
<div class="window-menubar">
    <div class="menu-item" id="menu-file">
        <span class="menu-label">File</span>
        <div class="menu-dropdown">
            <button class="dropdown-btn" id="btn-load-local">Open File...</button>
            <div class="menu-divider"></div>
            <button class="dropdown-btn" id="btn-exit">Exit</button>
        </div>
    </div>
    <div class="menu-item" id="menu-view">
        <span class="menu-label">View</span>
        <div class="menu-dropdown">
            <button class="dropdown-btn" id="btn-toggle-theme">Toggle Theme</button>
            <button class="dropdown-btn active" id="btn-view-drawer">Show Sidebar Drawer</button>
        </div>
    </div>
</div>
```

#### Option Menu Interaction Rules
- **Dropdown Activation**: Clicking a `.menu-item` adds `.active` class, revealing `.menu-dropdown` directly below the item label.
- **Active State Checkmark**: Adding `.active` class to a `.dropdown-btn` automatically prepends a retro checkmark (`✓`) via CSS `:before` pseudo-element.
- **Global Click-Away**: Document-level click handler closes all open dropdown menus (`closeAllMenus()`).

---

### C. Side Drawer Explorer Module (`.sidebar-drawer`)
A generic, pluggable side panel suitable for mounting project-specific file trees, navigation lists, or module selectors.

```html
<aside class="sidebar-drawer" id="sidebar-drawer">
    <div class="drawer-header">
        <span class="drawer-title">Navigation Explorer</span>
        <button class="drawer-action-btn" id="btn-drawer-action">
            <span>📁 Action Command</span>
        </button>
    </div>
    <div class="drawer-content">
        <!-- Generic Mount Point for Tree or Navigation List -->
        <div class="tree-container" id="file-tree"></div>
    </div>
</aside>

<!-- Drag Resizer Handle -->
<div class="sidebar-resizer" id="sidebar-resizer"></div>
```

#### Resizer Drag Mechanics
- `sidebar-resizer` (4px width) allows mouse dragging between `180px` min-width and `400px` max-width.
- When collapsed via `setSidebarVisible(false)`, both `.sidebar-drawer` and `.sidebar-resizer` have `display: none`.

---

### D. Main Client Viewport Panel (`.viewer-panel`)
The right-hand working client area split into a upper breadcrumb toolbar and scrolling content body.

```html
<main class="viewer-panel">
    <div class="viewer-toolbar">
        <div class="breadcrumb-container" id="breadcrumb">
            <span class="crumb">System</span>
            <span class="crumb-separator">&gt;</span>
            <span class="crumb active" id="current-doc-name">No file loaded</span>
        </div>
        <div class="toolbar-actions">
            <span class="file-size-badge" id="file-size-badge" style="display: none;">0 B</span>
        </div>
    </div>
    <div class="viewer-content" id="viewer-content">
        <!-- Main Project Content Mount Point -->
    </div>
</main>
```

---

### E. Status Bar (`.window-statusbar`)
Situated at the bottom of the window shell, styled as a 3-column CSS Grid (`grid-template-columns: 1fr 140px 80px`).

```html
<footer class="window-statusbar">
    <div class="status-cell" id="status-text">Status: Ready</div>
    <div class="status-cell" id="status-theme">Theme: Slate Dark</div>
    <div class="status-cell text-right" id="status-version">v1.0.5</div>
</footer>
```

---

## 4. Standalone Public API Reference (`window.MD2WEB_READER`)

To allow secondary projects to embed and orchestrate the GUI window shell, the runtime exposes a comprehensive global public API:

| API Function | Description |
| :--- | :--- |
| `MD2WEB_READER.setSidebarVisible(boolean)` | Programmatically shows (`true`) or hides (`false`) the side drawer & resizer. |
| `MD2WEB_READER.toggleSidebar(forceState?)` | Toggles the side drawer visibility state. |
| `MD2WEB_READER.setViewportMode(boolean)` | Toggles full viewport mode (`true`) or centered window mode (`false`). Triggers sidebar collapse/restore lifecycle hooks automatically. |
| `MD2WEB_READER.toggleViewportMode()` | Toggles viewport mode state. |
| `MD2WEB_READER.closeFile()` | Resets main viewport content to initial state and clears URL pushState routes. |
| `MD2WEB_READER.loadFile(filePath)` | Requests and renders a file target into the viewport. |
| `MD2WEB_READER.toggleTheme()` | Switches between Slate Dark Mode and Warm Cream Light Mode. |
| `MD2WEB_READER.getState()` | Returns a copy of current application runtime state object. |

---

## 5. Extraction Checklist for Secondary Projects

To re-use this GUI Emulator Shell in another application:

1. **Copy Styling**: Copy `public/res/css/cleanx.css` (provides all window bevel, titlebar, menubar, sidebar, statusbar, and dialog styles).
2. **Copy DOM Framework**: Copy `.window-container` HTML structure from `public/index.php`.
3. **Mount Custom Navigation**: Populate `#file-tree` inside `.drawer-content` with target project navigation nodes.
4. **Mount Custom Viewport**: Direct content rendering into `#viewer-content`.
5. **Attach Control API**: Utilize `window.MD2WEB_READER` (or alias `window.DESKTOP_GUI`) to control window state programmatically.

---

# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
