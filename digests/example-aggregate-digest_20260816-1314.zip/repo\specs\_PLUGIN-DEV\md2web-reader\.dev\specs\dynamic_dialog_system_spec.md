# Modular Dialog & Help System Architectural Specification

**Project:** md2web Reader  
**Specification target:** Extensible Help System & Standalone GUI Shell Extraction  
**Author:** vatofichor - Sebastian Mass & Gemini Antigravity  
**Date:** 2026-08-15  

---

## 1. Executive Summary & Architectural Intent

The `md2web Reader` utilizes a retro-modern Windows Classic GUI emulator shell (`#desktop-window`) featuring titlebars, dropdown menubars, resizable file drawer panels, and statusbar cells. Currently, modal dialog copy (such as the **Help > About** popup) is stored as inline HTML markup inside `public/index.php`.

To prepare the GUI emulator shell for standalone extraction across future projects and allow dynamic registration of arbitrary help tools and documentation modals, this specification defines a **Filesystem-Routed Modular Dialog System**.

```
+-----------------------------------------------------------------------+
|                           gui-window shell                            |
| +-------------------------------------------------------------------+ |
| | window-titlebar                                                   | |
| +-------------------------------------------------------------------+ |
| | window-menubar (File | View | Help -> About...)                   | |
| +-------------------------------+-----------------------------------+ |
| | sidebar-drawer                | viewer-panel                      | |
| | (Content Explorer Tree)       | (Markdown Render Area)            | |
| +-------------------------------+-----------------------------------+ |
| | window-statusbar                                                  | |
| +-------------------------------------------------------------------+ |
+-----------------------------------------------------------------------+
                                    |
                    [MD2WEB_READER.openDialog()]
                                    v
+-----------------------------------------------------------------------+
|                        #global-dialog overlay                         |
| +-------------------------------------------------------------------+ |
| | window-titlebar: #dialog-title                                    | |
| +-------------------------------------------------------------------+ |
| | #dialog-body-content  <--- fetch('api.php?action=dialog&name=...') | |
| |                             |                                       | |
| |                             v                                       | |
| |                    /content/dialogs/*.md                            | |
| |                    /content/dialogs/*.html                          | |
| +-------------------------------------------------------------------+ |
| | [ OK ] button                                                     | |
| +-------------------------------------------------------------------+ |
+-----------------------------------------------------------------------+
```

---

## 2. Directory Layout & Content Isolation

Adhering to the *Vatofichor Filesystem-Routed Module MVC* guidelines, all static copy, landing pages, and dialog definitions are decoupled from view scripts and stored as independent files inside a dedicated `/content/dialogs/` directory.

### Directory Mapping
```
d:/Dev/_PLUGIN-DEV/md2web-reader/
├── content/
│   ├── dialogs/
│   │   ├── about.md               # About md2web Reader modal copy
│   │   ├── help_shortcuts.md      # Keyboard Shortcuts & Navigation Guide
│   │   ├── license.md             # Open Source MIT License details
│   │   └── system_info.md         # Environment & PHP Runtime Diagnostics
│   ├── 01_Basics/
│   └── README.md
```

---

## 3. Server API Endpoint Specification (`public/api.php`)

The server API handles fetching dialog content fragments securely using canonical path traversal defense rules.

### Action: `action=dialog`
- **Request Parameter**: `name` (alphanumeric, hyphens, underscores).
- **Allowed Extensions**: `.md` or `.html`.
- **Target Resolution**: `$target = realpath(__DIR__ . '/../content/dialogs/' . $name . '.md')`

#### Security Logic Paradigm
1. Canonicalize base directory: `$baseDir = realpath(__DIR__ . '/../content/dialogs')`.
2. Compute requested path: `$target = realpath($baseDir . '/' . $name . '.md')` (or `.html`).
3. Enforce prefix validation: `strpos($target, $baseDir) === 0` to prevent directory traversal attacks (`../`).
4. Return JSON response containing compiled HTML or raw Markdown:

```json
{
  "status": "success",
  "name": "about",
  "title": "About md2web Reader",
  "content": "<div class=\"dialog-content\">...</div>",
  "size": 428
}
```

---

## 4. Universal Client Dialog Modal Shell (`public/index.php`)

Replace hardcoded, single-purpose dialog DOM structures with a unified, accessible modal shell.

```html
<!-- Reusable Generic Dialog Overlay -->
<div class="dialog-overlay" id="global-dialog" style="display: none;">
    <div class="dialog-box window-container">
        <div class="window-titlebar">
            <span class="titlebar-title" id="dialog-title">Dialog</span>
            <button class="titlebar-btn" id="btn-close-dialog" title="Close Dialog">×</button>
        </div>
        <div class="window-body dialog-body">
            <div class="dialog-content" id="dialog-body-content">
                <div class="tree-loading">Loading dialog content...</div>
            </div>
            <div class="dialog-footer">
                <button class="dialog-btn" id="btn-ok-dialog">OK</button>
            </div>
        </div>
    </div>
</div>
```

---

## 5. Client Public API (`public/res/js/app.js`)

Expose high-level dialog control functions on `window.MD2WEB_READER` to permit triggering modals programmatically from menu bar items, toolbar actions, or external host scripts.

### Method Signatures

```javascript
/**
 * Opens a dynamic dialog modal by fetching content from content/dialogs/{dialogName}.md
 * @param {string} dialogName - Filename slug under content/dialogs/ (e.g. 'about', 'help_shortcuts')
 * @param {string} [customTitle] - Optional titlebar string override
 */
window.MD2WEB_READER.openDialog = function(dialogName, customTitle) { ... };

/**
 * Closes the currently active global dialog modal
 */
window.MD2WEB_READER.closeDialog = function() { ... };
```

### Implementation Logic
```javascript
const openDialog = (dialogName, customTitle = '') => {
    const dialogOverlay = document.getElementById('global-dialog');
    const dialogTitle = document.getElementById('dialog-title');
    const dialogContent = document.getElementById('dialog-body-content');
    
    dialogTitle.textContent = customTitle || 'System Information';
    dialogContent.innerHTML = '<div class="tree-loading">Loading dialog content...</div>';
    dialogOverlay.style.display = 'flex';
    closeAllMenus();

    fetch(`api.php?action=dialog&name=${encodeURIComponent(dialogName)}`)
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                if (data.title && !customTitle) {
                    dialogTitle.textContent = data.title;
                }
                // Parse markdown via md2web parser if markdown fragment
                const htmlContent = (typeof md2web !== 'undefined' && typeof md2web.parseMarkdown === 'function')
                    ? md2web.parseMarkdown(data.content)
                    : data.content;
                dialogContent.innerHTML = htmlContent;
            } else {
                throw new Error(data.message || "Dialog content missing");
            }
        })
        .catch(err => {
            dialogContent.innerHTML = `<div style="color: var(--accent-red); padding: 10px;">Failed loading dialog: ${err.message}</div>`;
        });
};

const closeDialog = () => {
    const dialogOverlay = document.getElementById('global-dialog');
    if (dialogOverlay) dialogOverlay.style.display = 'none';
};
```

---

## 6. GUI Shell Extraction Blueprint for External Projects

When extracting the retro desktop emulator for deployment in secondary projects:

1. **Extract Core Assets**:
   - `public/res/css/cleanx.css` (retro window tokens, titlebar, menubar, statusbar, dialog styling).
   - `public/index.php` (minimal DOM shell holding `#desktop-window` and `#global-dialog`).
   - `public/res/js/app.js` (core window state, resizer, menu routing, dialog manager).
2. **Register Custom Help Tools**:
   - Add new items to `#menu-help` dropdown (e.g., `<button class="dropdown-btn" data-dialog="calculator_help">Calculator Help</button>`).
   - Bind click handler: `window.MD2WEB_READER.openDialog(e.target.dataset.dialog)`.
3. **Drop Markdown Help Files**:
   - Place markdown explainer guides into `/content/dialogs/`. No script re-compilation required.

---

# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
