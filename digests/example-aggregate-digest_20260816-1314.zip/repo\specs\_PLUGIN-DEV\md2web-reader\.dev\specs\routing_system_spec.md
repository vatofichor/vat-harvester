# System Spec: Filesystem Router & API Execution Defense

## 1. Architectural Overview

The **md2web Standalone Reader** utilizes a lightweight, zero-dependency filesystem router pattern powered by PHP's built-in development server (`cli-server` SAPI) and Apache `.htaccess` rewrites. 

### Core Components
1. **Root Router (`index.php`)**: Intercepts all incoming requests under the built-in server. Performs static file simulation, API endpoint routing, and hands off clean URL parameters to the public UI shell.
2. **Public Entry Shell (`public/index.php`)**: Generates dynamic `<base href="...">` tags for nested clean URL compatibility and serves the single-page reader UI.
3. **JSON API Endpoint (`public/api.php`)**: Handles document directory scanning (`action=list`) and safe content streaming (`action=read`) under traversal protection.
4. **Client App (`public/res/js/app.js`)**: Fetches document manifests asynchronously and drives reader state.

---

## 2. Router Implementation Logic

### Request Flow Pipeline in `index.php`

```mermaid
flowchart TD
    A[Incoming HTTP Request] --> B{php_sapi_name === 'cli-server'}
    B -- Yes --> C{File exists in root or /public?}
    C -- Yes --> D{File Extension === '.php'?}
    D -- No --> E[Serve static asset via readfile with Mime Type]
    D -- Yes --> F[Skip static fallback]
    C -- No --> F
    B -- No --> F
    F --> G{URI === 'api.php' or 'public/api.php'}
    G -- Yes --> H[require 'public/api.php']
    G -- No --> I[Set $_GET['route'] & require 'public/index.php']
```

---

## 3. The Bug: Static Asset Router Hijacking

### Symptom
When the client application initialized, `loadManifest()` in `app.js` executed:
```javascript
fetch('api.php?action=list')
```
The browser console threw a fatal promise rejection:
> `Uncaught (in promise) SyntaxError: Unexpected token '<', "<?php..." is not valid JSON`

### Root Cause Analysis
In the original `index.php` implementation, Section 1 attempted to serve static files from `/public/` for requests matching disk files under CLI server:

```php
// ORIGINAL DEFECTIVE LOGIC
if (php_sapi_name() === 'cli-server') {
    if (file_exists(__DIR__ . '/' . $uri) && is_file(__DIR__ . '/' . $uri)) {
        return false;
    }
    if (file_exists(__DIR__ . '/public/' . $uri) && is_file(__DIR__ . '/public/' . $uri)) {
        $filepath = __DIR__ . '/public/' . $uri;
        $mimeType = get_mime_type($filepath);
        header("Content-Type: $mimeType");
        readfile($filepath); // <--- DUMPED UNPARSED PHP SOURCE CODE
        exit;
    }
}
```

When `fetch('api.php?action=list')` hit `index.php`:
1. `$uri` was `'api.php'`.
2. `file_exists(__DIR__ . '/public/api.php')` evaluated to `TRUE`.
3. Because Section 1 **did not check the file extension**, it classified `api.php` as a static file.
4. `index.php` sent `Content-Type: application/octet-stream` and invoked `readfile('public/api.php')`.
5. The raw, unexecuted PHP source file (`<?php...`) was returned in the HTTP response body.
6. The frontend `res.json()` failed when encountering the leading `<` character of `<?php`.

---

## 4. The Fix: Extension-Aware Static Filtering

### Implementation

Section 1 of `index.php` was updated to explicitly inspect file extensions before initiating static streaming. Any file ending with `.php` bypasses static file serving and falls through to script execution.

```php
// REFACTORED SECURE ROUTING LOGIC
if (php_sapi_name() === 'cli-server') {
    if ($uri !== '' && file_exists(__DIR__ . '/' . $uri) && is_file(__DIR__ . '/' . $uri)) {
        $ext = strtolower(pathinfo($uri, PATHINFO_EXTENSION));
        if ($ext !== 'php') {
            return false; // Let CLI server serve non-PHP static files in root directly
        }
    }
    if (file_exists(__DIR__ . '/public/' . $uri) && is_file(__DIR__ . '/public/' . $uri)) {
        $ext = strtolower(pathinfo($uri, PATHINFO_EXTENSION));
        if ($ext !== 'php') {
            $filepath = __DIR__ . '/public/' . $uri;
            $mimeType = get_mime_type($filepath);
            header("Content-Type: $mimeType");
            readfile($filepath);
            exit;
        }
    }
}
```

---

## 5. Verification & Test Results

### 1. PHP Syntax Verification
```powershell
php -l index.php; php -l public/api.php; php -l public/index.php
# Output: No syntax errors detected in all targets.
```

### 2. Live Server Scan API Output (`curl.exe`)
```bash
curl.exe -s "http://localhost:8080/api.php?action=list"
```
**Response Body**:
```json
{"status":"success","files":[{"name":"README.md","path":"README.md","size":1982,"modified":1782594536},{"name":"markdown-spec.md","path":"markdown-spec.md","size":4029,"modified":1781405708}]}
```

---

# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
