# Canvas Configuration, Sizing, and Typography Specification

This document details the architecture, configuration parameters, device pixel ratio (DPI) backing-store scaling algorithms, and dynamic configuration rules for a unified, extensible Canvas Configuration and Theme System across all modules.

---

## 1. Overview
The canvas configuration system serves as a centralized registry for all metadata, dimensions, typography, color constants, and animation parameters needed by HTML5 Canvas widgets. Rather than hardcoding dimensions or font configurations inside individual modules, they are resolved from a global, responsive configuration space.

```mermaid
graph TD
    Start[resizeCanvas canvas] --> FindParent[Find parent element clientWidth & clientHeight]
    FindParent --> GetDPR[Get window.devicePixelRatio or 1]
    GetDPR --> ScrollCheck{Is parent scrollable?}
    ScrollCheck -- Yes --> MinWidth[Set backing width to Max: 650px or clientWidth]
    ScrollCheck -- No --> MatchWidth[Set backing width to clientWidth]
    MinWidth --> ScaleBacking[Multiply backing width & height by DPR]
    MatchWidth --> ScaleBacking
    ScaleBacking --> AssignBacking[Assign canvas.width & canvas.height]
    AssignBacking --> StyleCSS[Assign canvas.style.width & canvas.style.height in CSS pixels]
    StyleCSS --> ScaleContext[Execute ctx.scale DPR, DPR to normalize drawing coordinates]
    ScaleContext --> End[Canvas Ready for High-DPI Drawing]
```

---

## 2. Configuration Schema (`window.CANVAS_CONFIG`)
The configuration system exposes a generalized namespace `window.CANVAS_CONFIG` inside [shared.js](file:///d:/Dev/play-math/assets/shared.js) which holds typography rules, layout dimensions, default animations, and theme color defaults:

```javascript
window.CANVAS_CONFIG = {
    // Typography definitions
    fonts: {
        title: "bold 20px Outfit, sans-serif",
        subtitle: "bold 16px Outfit, sans-serif",
        label: "600 14px Outfit, sans-serif",
        monoLabel: "500 14px 'JetBrains Mono', monospace",
        monoSmall: "500 12px 'JetBrains Mono', monospace"
    },
    
    // Layout and sizing presets
    dimensions: {
        padding: 15,
        gridSize: 32,
        blockSpacing: 3,
        dotRadius: 4
    },
    
    // Animation constants
    animations: {
        pauseDelay: 2000, // 2-second default animation pause timing
        speedFactor: 1.0
    },

    // Global layout color schemes for scripts
    colors: {
        coef: '#f43f5e',
        variable: '#38bdf8',
        constant: '#10b981',
        exponent: '#a855f7'
    }
};
```

---

## 3. Backing-Store Resizing Engine (`window.resizeCanvas`)
The centralized canvas scaling utility is declared on the `window` object by `shared.js` to automatically keep drawings crisp across device screen transitions:

```javascript
window.resizeCanvas = function(canvasElement) {
    const container = canvasElement.parentElement;
    const ctx = canvasElement.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    
    // 1. Determine layout width (support scrollable containers)
    let layoutW = container.clientWidth;
    if (container.classList.contains('scrollable-canvas-container')) {
        layoutW = Math.max(650, layoutW);
    }
    const layoutH = container.clientHeight;
    
    // 2. Set backing store dimensions (physical pixels)
    canvasElement.width = layoutW * dpr;
    canvasElement.height = layoutH * dpr;
    
    // 3. Set display dimensions (CSS pixels)
    canvasElement.style.width = layoutW + 'px';
    canvasElement.style.height = layoutH + 'px';
    
    // 4. Scale coordinate space to let standard drawing calls write natively
    ctx.scale(dpr, dpr);
    
    return dpr;
};
```

---

## 4. Module Implementation Standard

When drawing inside a template's JavaScript block, individual modules must implement this standard by removing local duplicate definitions and referencing the centralized config:

```javascript
function drawVisualization() {
    // 1. Resize and scale the canvas
    window.resizeCanvas(myCanvas);
    
    const w = myCanvas.clientWidth;
    const h = myCanvas.clientHeight;
    
    // 2. Draw using standardized configuration
    ctx.fillStyle = window.CANVAS_CONFIG.colors.coef;
    ctx.font = window.CANVAS_CONFIG.fonts.label;
    ctx.fillText("Term Coefficient", w / 2, h / 2);
    
    // Draw dot with standard radius
    ctx.beginPath();
    ctx.arc(w / 2, h / 2 + 30, window.CANVAS_CONFIG.dimensions.dotRadius, 0, Math.PI * 2);
    ctx.fill();
}
```

---
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
