# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\

# System Specification: Display Scaling & Viewport Centering Engine (BREAKOUT2)

## 1. Executive Overview & System Architecture
The **Display Scaling & Viewport Centering Engine** provides real-time, high-density UI and HTML5 Canvas zoom scaling across 7 discrete increments (**25%**, **50%**, **75%**, **100%**, **125%**, **150%**, **175%**).

Designed for accessibility, mobile viewports, and high-DPI Windows display scaling (125%/175% OS DPI), the engine dynamically adjusts layout dimensions, canvas backing store resolutions, and 2D/3D visualizer drawing origins while guaranteeing visual centering without horizontal skew or off-screen drift.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      Sidebar Navigation Drawer                             │
│ ┌─────────────────────────────────────────────────────────────────────────┐ │
│ │  Display Scaling Controller (25% | 50% | 75% | 100% | 125% | 150% | 175%)  │ │
│ └───────────────────────────────┬─────────────────────────────────────────┘ │
└─────────────────────────────────┼───────────────────────────────────────────┘
                                  │ (click event)
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                       Global Shared Engine (shared.js)                      │
│  1. localStorage.setItem('algebralab_user_scale', scaleVal)                 │
│  2. :root { --user-scale: scaleVal }                                        │
│  3. void document.body.offsetHeight (force DOM reflow)                      │
│  4. window.dispatchEvent(new Event('resize'))                               │
└─────────────────────────────────┬───────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                   DOM Layout & Canvas Viewport Engines                      │
│  - CSS: .workspace-grid { zoom: var(--user-scale); transform-origin... }    │
│  - CSS: .canvas-container { height: clamp(240px, calc(360px*scale), 650px) } │
│  - JS:  window.getCanvasViewport() -> cx = (0.38*layoutW) - (0.35*layoutW*Δs)│
│  - JS:  window.resizeCanvas() -> canvas.width = layoutW * dpr (crisp 2x/3x) │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Mandatory HTML DOM Requirements

To operate seamlessly, pages consuming the scaling engine must adhere to the following DOM structure:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../../assets/shared.css">
    <script src="../../assets/shared.js"></script>
</head>
<body>
    <!-- 1. Sidebar Drawer (Injected with .sidebar-header logo wrapper) -->
    <aside></aside>

    <!-- 2. Main Content Workspace -->
    <main>
        <header>
            <h1>Module Title</h1>
            <p>Module Description...</p>
        </header>

        <!-- 3. Workspace Grid Container -->
        <section id="moduleSection">
            <div class="workspace-grid">
                <!-- Left Panel: Canvas Container -->
                <div class="panel">
                    <div class="canvas-container">
                        <canvas id="moduleCanvas"></canvas>
                    </div>
                </div>

                <!-- Right Panel: Controls -->
                <div class="panel">
                    <!-- Sliders & Interactive Controls -->
                </div>
            </div>
        </section>
    </main>
</body>
</html>
```

---

## 3. Sidebar Navigation Control System (`assets/shared.js`)

### 3.1 Control Mounting Logic
The scaling controller is generated dynamically during `DOMContentLoaded` and injected directly into the sidebar navigation drawer beneath the logo header:

```javascript
const savedScale = localStorage.getItem('algebralab_user_scale') || '1.0';
document.documentElement.style.setProperty('--user-scale', savedScale);

const buildScaleBtnHtml = (activeScale) => `
    <button class="display-scale-btn ${activeScale === '0.25' ? 'active' : ''}" data-scale="0.25">25%</button>
    <button class="display-scale-btn ${activeScale === '0.5' ? 'active' : ''}" data-scale="0.5">50%</button>
    <button class="display-scale-btn ${activeScale === '0.75' ? 'active' : ''}" data-scale="0.75">75%</button>
    <button class="display-scale-btn ${activeScale === '1.0' ? 'active' : ''}" data-scale="1.0">100%</button>
    <button class="display-scale-btn ${activeScale === '1.25' ? 'active' : ''}" data-scale="1.25">125%</button>
    <button class="display-scale-btn ${activeScale === '1.5' ? 'active' : ''}" data-scale="1.5">150%</button>
    <button class="display-scale-btn ${activeScale === '1.75' ? 'active' : ''}" data-scale="1.75">175%</button>
`;

if (logoWrapper && !document.querySelector('.sidebar-scale-box')) {
    const sidebarScaleBox = document.createElement('div');
    sidebarScaleBox.className = 'sidebar-scale-box';
    sidebarScaleBox.innerHTML = `
        <span class="scale-title">Display Scaling</span>
        <div class="display-scale-buttons">
            ${buildScaleBtnHtml(savedScale)}
        </div>
    `;
    logoWrapper.after(sidebarScaleBox);
}
```

### 3.2 State Synchronization & Instant Reflow Event Model
```javascript
document.querySelectorAll('.display-scale-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const selectedVal = e.currentTarget.getAttribute('data-scale');

        document.querySelectorAll('.display-scale-btn').forEach(b => {
            if (b.getAttribute('data-scale') === selectedVal) {
                b.classList.add('active');
            } else {
                b.classList.remove('active');
            }
        });

        localStorage.setItem('algebralab_user_scale', selectedVal);
        document.documentElement.style.setProperty('--user-scale', selectedVal);

        // Force synchronous DOM layout reflow before triggering resize event
        void document.body.offsetHeight;

        // Trigger immediate live rebuild & canvas redraw
        window.dispatchEvent(new CustomEvent('app-scale-change', { detail: { scale: parseFloat(selectedVal) } }));
        window.dispatchEvent(new Event('resize'));
    });
});
```

---

## 4. Canvas Resizing & Viewport Centering Engine (`assets/shared.js`)

### 4.1 High-DPI Backing Store Canvas Resizer
```javascript
window.resizeCanvas = function (canvasElement) {
    const container = canvasElement.parentElement;
    const ctx = canvasElement.getContext('2d');
    const dpr = window.devicePixelRatio || 1;

    let layoutW = container.clientWidth;
    if (container.classList.contains('scrollable-canvas-container')) {
        layoutW = Math.max(650, layoutW);
    }
    const layoutH = container.clientHeight;

    canvasElement.width = layoutW * dpr;
    canvasElement.height = layoutH * dpr;

    canvasElement.style.width = layoutW + 'px';
    canvasElement.style.height = layoutH + 'px';

    ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset transform matrix
    ctx.scale(dpr, dpr);
    return dpr;
};
```

### 4.2 Mathematical Viewport Centering & Coefficient Offset Engine
To prevent horizontal drift as scale varies from 25% to 175%, the engine computes a scale distance coefficient ($\Delta_s = \text{userScale} - 1.0$) and applies a shift to the base center:

$$\text{cx} = \left(\text{layoutW} \cdot 0.38\right) - \left(\text{layoutW} \cdot 0.35 \cdot \Delta_s\right)$$

```javascript
window.getCanvasViewport = function (canvasElement) {
    const container = canvasElement.parentElement;
    const dpr = window.devicePixelRatio || 1;
    const rawScale = localStorage.getItem('algebralab_user_scale') || '1.0';
    const userScale = parseFloat(rawScale) || 1.0;

    let layoutW = container.clientWidth;
    if (container.classList.contains('scrollable-canvas-container')) {
        layoutW = Math.max(650, layoutW);
    }
    const layoutH = container.clientHeight;

    // Base center shifted left (0.38 layoutW) + scale distance coefficient correction
    const scaleDelta = userScale - 1.0;
    const baseCenter = layoutW * 0.38;
    const centerCorrectionX = layoutW * 0.35 * scaleDelta;
    const cx = baseCenter - centerCorrectionX;

    return {
        cx: cx,
        cy: layoutH / 2,
        width: layoutW,
        height: layoutH,
        dpr: dpr,
        userScale: userScale,
        scaleDelta: scaleDelta
    };
};
```

---

## 5. CSS Design System & Container Mechanics (`assets/shared.css`)

```css
:root {
    --user-scale: 1.0;
}

/* 1. Live Rescale Workspace Grid */
.workspace-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.5rem;
    align-items: start;
    zoom: var(--user-scale, 1.0);
    transform-origin: top center;
    margin: 0 auto;
}

/* 2. Responsive Clamp Canvas Container */
.canvas-container {
    width: 100%;
    height: clamp(240px, calc(360px * var(--user-scale, 1.0)), 650px);
    background: rgba(0, 0, 0, 0.25);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.03);
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    touch-action: none;
}

canvas {
    display: block;
    background: transparent;
}

/* 3. Sidebar Scale Controller Widget Styles */
.sidebar-scale-box {
    margin-bottom: 1.5rem;
    padding: 0.85rem 1rem;
    background: rgba(255, 255, 255, 0.02);
    border: 1px solid var(--card-border);
    border-radius: 14px;
}

.sidebar-scale-box .scale-title {
    display: block;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--text-muted);
    margin-bottom: 8px;
}

.display-scale-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    width: 100%;
}

.display-scale-btn {
    flex: 1;
    min-width: 38px;
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.06);
    color: var(--text-muted);
    padding: 5px 6px;
    border-radius: 10px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.75rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    text-align: center;
}

.display-scale-btn:hover {
    color: var(--text-color);
    background: rgba(255, 255, 255, 0.08);
    border-color: rgba(255, 255, 255, 0.12);
}

.display-scale-btn.active {
    background: var(--color-accent, #38bdf8);
    color: #000000;
    border-color: var(--color-accent, #38bdf8);
    box-shadow: 0 0 10px var(--color-accent-glow, rgba(56, 189, 248, 0.35));
}
```

---

## 6. Developer Reimplementation Guide

To recreate or implement this scaling system in a new module or project:

1. **Step 1 — Include Core Files**:
   Link `assets/shared.css` and `assets/shared.js` inside the `<head>` of your HTML document.

2. **Step 2 — Purge Local `resizeCanvas` Overrides**:
   Do **NOT** declare `function resizeCanvas()` inside individual page script tags. Inherit `window.resizeCanvas` and `window.getCanvasViewport` directly from `shared.js`.

3. **Step 3 — Refactor Module Drawing Routines**:
   Inside your canvas draw function:
   ```javascript
   function drawSimulation() {
       resizeCanvas(myCanvas);
       const vp = window.getCanvasViewport(myCanvas);
       
       ctx.clearRect(0, 0, vp.width, vp.height);
       
       // Anchor objects around vp.cx and vp.cy
       const objectSize = Math.min(24 * vp.userScale, (vp.width - 60) / 4);
       const startX = vp.cx - objectWidth / 2;
       const startY = vp.cy - objectHeight / 2;

       // Draw shapes...
   }
   ```

4. **Step 4 — 3D Isometric Midpoint Normalization**:
   For 3D isometric cube projections, calculate vertical Y bounds `minIsoY` and `maxIsoY` and subtract `isoCenterY = (minIsoY + maxIsoY) / 2`:
   ```javascript
   const by = vp.cy - isoCenterY + isoY - 10;
   ```

5. **Step 5 — Register Resize Event Listener**:
   ```javascript
   window.addEventListener('resize', () => {
       drawSimulation();
   });
   ```

---

## 7. Operational Considerations & System Constraints

- **No Multi-Header Duplication**: The scaling control widget mounts strictly inside `.sidebar-scroll-container` to keep header layouts clean and uncluttered.
- **DPR Backing Stores**: `canvas.width = layoutW * dpr` ensures retina/4K sharpness. Never set raw canvas pixel dimensions without DPR multiplication.
- **Forced DOM Reflow**: Always invoke `void document.body.offsetHeight;` prior to triggering `resize` events on scale state mutation.
