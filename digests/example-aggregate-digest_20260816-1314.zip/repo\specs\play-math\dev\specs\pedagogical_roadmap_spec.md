# Pedagogical & Mathematics Roadmap Spec

This document details the curricular structure, pedagogical philosophy, and design reasoning behind the **Play-Math** interactive workspace. It serves as a reference for academics, parents, and educators looking to understand how the system maps abstract mathematical concepts to intuitive, spatial, and visual sandboxes.

---

## 1. Pedagogical Philosophy: "The Play-Math Way"

Traditional mathematics education often suffers from two extremes: **rote algorithmic memorization** (learning rules without understanding why they work) and **black-box software tools** (where a computer prints the answer, leaving the step-by-step logic hidden).

**Play-Math** is designed on a third paradigm: **Physicalized Rigor**. We adhere to four core pillars:

1. **Spatial & Geometric Intuition First**: Every algebraic, computational, or calculus concept is mapped to a physical geometry. For example, multiplying binomials $(x+p)(x+q)$ is represented as partitioning a 2D area, and the difference of cubes $a^3 - b^3$ is visualized as cutting and partitioning a 3D isometric solid.
2. **Real-Time Interactive Continuity**: By using high-density HTML5 canvas rendering and mouse/touch tracking, students do not just see static formulas; they observe the continuity of math. They watch roots branch symmetrically into the complex plane as a discriminant crosses below zero, or watch a balance scale tilt and realign as they apply algebraic operations.
3. **Rigorous Handling of Constraints**: Mathematics is defined by boundaries. Instead of simplifying mathematical rules, Play-Math features active alerts for division-by-zero, extraneous roots (e.g. fractional equations yielding a zero denominator), parallel lines (inconsistent systems), and coincident lines (infinite solutions).
4. **Parent & Instructor Guided Analysis**: Each module includes a rigorous, text-dense **Analysis Section** with math definitions, theorems, and proofs. This is not designed for direct ingestion by young learners on their own. Instead, parents and instructors of younger students should actively utilize these sections to guide lessons, while older students can use them directly for self-guided retrospect.

---

## 2. Curricular Roadmap & Domain Reasoning

The curriculum synthesized in Play-Math comprises 7 main domains covering a total of 79 subtopics, structured to take learners from foundational number sense to computational programming math.

```mermaid
graph TD
    Step1["1. Arithmetic & Number Sense (Foundation)"] --> Step2["2. Algebraic Structures (Symbolic Isolation)"]
    Step2 --> Step3["3. Geometry & Space (Spatial Relationships)"]
    Step2 --> Step4["4. Trigonometry & Waves (Periodic Motion)"]
    Step2 --> Step5["5. Calculus & Limits (Continuous Change)"]
    Step2 --> Step6["6. Data & Stats (Probability & Distributions)"]
    Step2 --> Step7["7. Computational Math (Logic & Matrices)"]
```

### Step 01: Arithmetic & Number Sense (`01_arithmetic_number_sense`)
* **Learning Objective**: Deepen understanding of integers, primes, divisibility, factors, fractions, order of operations, and decimal conversions.
* **Pedagogical Reasoning**: Solidifies the operational properties of real numbers before abstract symbols are introduced. Fractions are taught as ratios, and order of operations is shown as a hierarchy of operations.

### Step 02: Algebraic Structures (`02_algebra`)
* **Learning Objective**: Master variables isolation, linear equations (one and two variables), quadratics, discriminants, factoring expansions, functions, and coordinate systems.
* **Pedagogical Reasoning**: Transitions students from evaluating fixed arithmetic to isolating unknown values. We use the **Balance Scale Model** to represent the equality property (adding/subtracting/dividing symmetrically on both sides) and the **Vertical Line Test/Set-Mapping** to build formal mappings definitions.

### Step 03: Geometry & Space (`03_geometry_measurement`)
* **Learning Objective**: Explore angles, triangles, polygons, perimeter/area, 3D volume, Pythagorean theorem, and coordinate translations.
* **Pedagogical Reasoning**: Anchors geometric formulas to visual sliders, enabling students to scale shape bounds and directly see how changes in 1D lengths affect 2D areas and 3D volumes quadratic/cubic growth.

### Step 04: Trigonometry & Waves (`04_trigonometry`)
* **Learning Objective**: Understand unit circle angles, sine/cosine/tangent ratios, waveforms, amplitudes, periods, and phase shifts.
* **Pedagogical Reasoning**: Shows the direct connection between circular rotation and linear waveforms. Moving an angle around the unit circle draws the corresponding sine/cosine wave in real-time, helping students grasp periodic motion.

### Step 05: Calculus & Limits (`05_calculus`)
* **Learning Objective**: Introduce continuous change, limits, tangents, derivatives, integrals, and optimization.
* **Pedagogical Reasoning**: Demystifies calculus by demonstrating limits geometrically. The student can slide two points together on a function curve, watching the secant line morph into the tangent derivative line as the delta approaches zero.

### Step 06: Data Science & Statistics (`06_data_science_statistics`)
* **Learning Objective**: Analyze distributions, standard deviation, mean/median/mode, regression lines, probability trees, and graphing datasets.
* **Pedagogical Reasoning**: Focuses on parsing real-world patterns. Students adjust outlier values and watch the median, mean, and regression slope react, building an intuitive understanding of data sensitivity.

### Step 07: Computational Math (`07_computational_math`)
* **Learning Objective**: Connect pure mathematics to computer science through logic gates, binary formats, matrix operations, vectors, and graph algorithms.
* **Pedagogical Reasoning**: Shows how truth tables translate to logic gates (AND/OR/NOT) and how coordinate rotations are driven by linear algebra vector-matrix multiplications.

---

## 3. Structural Design of Modules

Each interactive workspace module in the curriculum is designed with the same high-density, old-school desktop tool aesthetic (dark mode grid layout, no popup modals):

1. **Dashboard Hub**: Displays active subtopics and lists clear, focused checklist tasks.
2. **Interactive Simulator**: The core canvas visualizer where students manipulate variables via sliders and drag/touch.
3. **Step-by-Step Solver**: Evaluates algebraic processes and substitutions numerically in real-time, matching the active state of the simulator.
4. **Conceptual Quiz**: Multiple-choice evaluation questions focusing on concepts and edge cases, providing detailed explanations immediately on selection.
5. **Dense Analysis Section**: Compiles core mathematical definitions, theorems, and structural notes. This section is geared towards parents, tutors, and older students for reflection and retrospect, rather than young learners navigating alone.

---
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\
