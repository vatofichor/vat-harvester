# Style Specification Sheet: Bookkeeping Cheatsheet Intro

```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\  
```

**Target Workspace File**: [Bookkeeping_Cheatsheet_Intro.html](file:///d:/Dev/qbo_bookkeeping_payroll_mod/dev/guides/Bookkeeping_Cheatsheet_Intro.html)  
**Document Mode**: Administrative / Design Architecture Spec  
**Last Updated**: 2026-08-10  

---

## 1. Executive Summary & Design System

The styling of `Bookkeeping_Cheatsheet_Intro.html` is engineered for **high-density technical reference, maximum legibility, and effortless navigation**. It utilizes a self-contained Vanilla CSS custom property design system (`:root[data-theme]`) paired with dual typography stacks from Google Fonts (`Plus Jakarta Sans` for UI copy and `JetBrains Mono` for code, equations, and telemetry data).

### Core Design Principles:
1. **Zero External CSS Framework Dependencies**: Tailored custom CSS properties eliminate overhead and prevent CSS selector bloat.
2. **Dual-Theme Engine**: Dark mode by default (`#0b0f19` slate background) with instantaneous client-side switching to Light mode (`#f8fafc`).
3. **High-Density Grid Layouts**: Responsive CSS Grid and Flexbox cards present complex GAAP rules, double-entry debit/credit distinctions, and financial statements in compact visual units.
4. **Accessible Contrast & Visual Hierarchy**: Strict contrast ratios, visual accent pill badges, color-coded card borders, and emerald green mathematical highlights.

---

## 2. Design Tokens & CSS Custom Properties

Both themes are declared on `:root[data-theme]` to allow instant theme toggling without full DOM re-renders or stylesheet swaps.

### 2.1 CSS Variable Matrix

| Variable Name | Dark Theme (`data-theme="dark"`) | Light Theme (`data-theme="light"`) | Functional Purpose |
| :--- | :--- | :--- | :--- |
| `--bg-page` | `#0b0f19` | `#f8fafc` | Main viewport canvas background |
| `--bg-panel` | `#111827` | `#ffffff` | Elevated header panel & card backgrounds |
| `--border-color` | `#374151` | `#e2e8f0` | Structural dividers, card & table borders |
| `--text-main` | `#ffffff` | `#0f172a` | Primary body text & heading color |
| `--text-muted` | `#9ca3af` | `#64748b` | Subtitles, meta tags, and footer notes |
| `--accent` | `#6366f1` | `#4f46e5` | Primary indigo accent (links, buttons, borders) |
| `--accent-hover` | `#4f46e5` | `#4338ca` | Button hover & active interaction states |
| `--accent-light` | `rgba(99, 102, 241, 0.15)` | `rgba(79, 70, 229, 0.1)` | Tinted blockquote & badge backgrounds |
| `--shadow` | `0 4px 20px -2px rgba(0,0,0,0.7)` | `0 4px 20px -2px rgba(0,0,0,0.08)` | Card elevation shadow |
| `--pre-bg` | `#030712` | `#f1f5f9` | Code block container background |
| `--code-bg` | `#1e1b4b` | `#fee2e2` | Inline code highlight fill |
| `--code-text` | `#e0e7ff` | `#b91c1c` | Inline code text color |
| `--table-th-bg` | `#1f2937` | `#f1f5f9` | Table header cell background |
| `--table-tr-even-bg` | `#161e29` | `#f8fafc` | Alternating table row background |
| `--math-text` | `#10b981` | `#059669` | Mathematical formula emerald color |

---

## 3. Typography & Font Hierarchy

### 3.1 Font Stacks
- **UI & Content Body Font**: `'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`
  - Weights: `300` (Light), `400` (Regular), `500` (Medium), `600` (SemiBold), `700` (Bold)
- **Code & Equations Font**: `'JetBrains Mono', Consolas, monospace`
  - Weights: `400` (Regular), `500` (Medium), `700` (Bold)

### 3.2 Heading Hierarchy

```css
.markdown-body h1, .markdown-body h2, .markdown-body h3, .markdown-body h4 {
    color: var(--text-main);
    font-weight: 700;
    margin-top: 2rem;
    margin-bottom: 1rem;
    border-bottom: 1px solid var(--border-color);
    padding-bottom: 0.3em;
    scroll-margin-top: 80px; /* Header clearance */
}

.markdown-body h1, .markdown-body h2 {
    font-variant: small-caps;
}

.markdown-body h1 { font-size: 2.2em; }
.markdown-body h2 { font-size: 1.6em; }
.markdown-body h3 { font-size: 1.3em; border-bottom: none; }
```

> [!NOTE]
> `scroll-margin-top: 80px` guarantees that anchor jump links land cleanly below the 64px sticky header bar without obscuring heading titles.

---

## 4. Layout Architecture & Structural Components

### 4.1 Sticky Top Navigation Header (`header`)
- **Position**: `sticky`, `top: 0`, `z-index: 100`
- **Dimensions**: `height: 64px`, `padding: 0 40px`
- **Styling**: `background-color: var(--bg-panel)`, `border-bottom: 1px solid var(--border-color)`
- **Content Layout**: Flexbox row (`justify-content: space-between`, `align-items: center`)
- **Actions**: Theme Toggle button (`#themeBtn`) + Print/PDF Export button (`window.print()`).

### 4.2 Content Container (`.container`)
- **Dimensions**: `max-width: 960px`, `width: 100%`, `margin: 0 auto`
- **Padding**: `40px 30px`
- **Flow**: Flex item spanning remaining viewport height (`flex: 1`).

---

## 5. UI Component Library & Visual Cards

### 5.1 Multi-Column Table of Contents Grid
- **CSS Grid**: `display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;`
- **Category Columns (4 Columns)**:
  1. Foundations & Principles (Indigo Accent)
  2. Assets, Sales & Inventory (Indigo Accent)
  3. Liabilities, Equity & Payroll (Indigo Accent)
  4. Reconciliations & Analysis (Indigo Accent)
- **Jump Link Overrides**:
  - Dark Mode: `#ffffff` text with underline (`opacity: 0.8` on hover)
  - Light Mode: `#000000` text with underline (`opacity: 0.8` on hover)

### 5.2 Accounting Callout Cards (Debit / Credit / AP / AR)
- **Container Style**: `background-color: var(--bg-panel); border: 1px solid var(--border-color); border-radius: 12px; padding: 20px; box-shadow: var(--shadow);`
- **Color Accent Left Borders**:
  - **Debit (Dr)**: `border-left: 5px solid #6366f1;` (Indigo Destination Pill: `rgba(99,102,241,0.15)`)
  - **Credit (Cr)**: `border-left: 5px solid #8b5cf6;` (Purple Origin Pill: `rgba(139,92,246,0.15)`)
  - **Accounts Payable (AP)**: `border-left: 5px solid #d97706;` (Amber Bills Pill: `rgba(217,119,6,0.15)`)
  - **Accounts Receivable (AR)**: `border-left: 5px solid #0284c7;` (Sky Blue Customer Pill: `rgba(2,132,199,0.15)`)

### 5.3 Financial Concept Cards (Sales vs Revenue vs Income)
- **Flex Grid**: `display: flex; flex-wrap: wrap; gap: 14px; align-items: stretch;`
- **Card Box**: `flex: 1; min-width: 180px; border: 1px solid var(--border-color); border-radius: 10px; padding: 14px 16px; position: relative;`
- **Pill Badges**: `font-size: 11px; text-transform: uppercase; color: var(--accent);`

### 5.4 Blockquotes & Mathematical Formula Highlights
- **Blockquote**:
  ```css
  .markdown-body blockquote {
      border-left: 4px solid var(--accent);
      background-color: var(--accent-light);
      padding: 1rem 1.5rem;
      margin-bottom: 1.2rem;
      border-radius: 0 8px 8px 0;
      color: var(--text-main);
  }
  ```
- **Math Formula Highlights (`.math`)**:
  ```css
  .markdown-body .math {
      font-family: 'JetBrains Mono', Consolas, monospace;
      color: var(--math-text);
      background-color: rgba(16, 185, 129, 0.1);
      padding: 0.1rem 0.3rem;
      border-radius: 4px;
      font-style: italic;
  }
  ```

### 5.5 Data Tables
- **Grid Formatting**: `width: 100%`, `border-collapse: collapse`
- **Cells (`th`, `td`)**: `padding: 12px 16px; border: 1px solid var(--border-color);`
- **Striping**: Even rows highlighted with `var(--table-tr-even-bg)` (`#161e29` dark / `#f8fafc` light).

---

## 6. JavaScript Interactivity & Smooth Navigation

```javascript
// Theme Switching Engine
function toggleTheme() {
    const html = document.documentElement;
    const nextTheme = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', nextTheme);
}

// Header-Aware Smooth Anchor Navigation
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href').substring(1);
            if (!targetId) return;

            let target = document.getElementById(targetId);
            if (!target) {
                // Fallback: Heading slug search
                const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
                for (let h of headings) {
                    const slug = h.textContent.trim().toLowerCase()
                        .replace(/[^\w\s\-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-');
                    if (slug === targetId || slug.includes(targetId)) {
                        target = h;
                        break;
                    }
                }
            }
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});
```

---

## 7. Print & PDF Export Profile (`@media print`)

```css
@media print {
    body {
        background: #fff;
        color: #000;
    }
    header {
        display: none;
    }
    .container {
        max-width: 100%;
        padding: 0;
    }
}
```

---

## 8. Verification & Style Audit Checklist

- [x] Dual-theme variables properly mapped on `:root[data-theme]` selector.
- [x] Monospace and sans-serif Google Fonts imported via preconnect.
- [x] All 100 Table of Contents anchors link cleanly to valid section targets.
- [x] Cards feature contrast-compliant badges and border accents.
- [x] Printable stylesheet suppresses top navigation and expands content canvas.
