# Specification Sheet: Bookkeeping TOC Search & Dynamic Filtering Engine

```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\  
```

This specification sheet provides the localized architectural blueprint for integrating the **Live TOC Search & Category Filtering Engine** into [Bookkeeping_Cheatsheet_Intro.html](file:///d:/Dev/qbo_bookkeeping_payroll_mod/dev/guides/Bookkeeping_Cheatsheet_Intro.html).

---

## 1. Architectural Overview

The Bookkeeping TOC Search engine is a zero-dependency client-side filter designed to filter 100 Table of Contents topics across 4 grid column categories in sub-milliseconds:
1. **Foundations & Principles**
2. **Assets, Sales & Inventory**
3. **Liabilities, Equity & Payroll**
4. **Reconciliations & Analysis**

### Key Features
- **Real-Time Keypress Filtering**: Instantly filters `<li>` topic links based on user input.
- **Keyboard Focus Shortcuts**: Press `/` to focus the search bar; press `Escape` to clear search and blur input.
- **Dynamic Topic Counter**: Real-time feedback (`Showing X of 100 Topics`).
- **Auto-Collapsing Category Cards**: Dynamically hides column cards when zero matching topics remain within that category.

---

## 2. Component Markup Contract

### Search Hero Bar Component (`#tocSearchHero`)
```html
<div class="toc-search-section" style="margin: 20px 0;">
    <div style="position: relative; width: 100%;">
        <svg style="position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: var(--text-muted); pointer-events: none;" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        <input type="text" id="tocSearchInput" placeholder="Filter 100 bookkeeping topics... (Press '/' to focus)" 
            style="width: 100%; padding: 12px 18px 12px 46px; background-color: var(--bg-panel); border: 1px solid var(--border-color); border-radius: 10px; color: var(--text-main); font-size: 14px; font-family: inherit; outline: none; transition: border-color 0.2s ease;">
        <span style="position: absolute; right: 14px; top: 50%; transform: translateY(-50%); background-color: var(--bg-page); border: 1px solid var(--border-color); color: var(--text-muted); font-family: 'JetBrains Mono', monospace; font-size: 11px; padding: 2px 6px; border-radius: 4px; pointer-events: none;">/</span>
    </div>
</div>
```

---

## 3. JavaScript Execution Engine

```javascript
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('tocSearchInput');
    const tocCounter = document.getElementById('tocCounter');
    const categoryCards = document.querySelectorAll('.toc-category-card');
    
    if (!searchInput) return;

    searchInput.addEventListener('input', executeTocFilter);

    window.addEventListener('keydown', (e) => {
        if (e.key === '/' && document.activeElement !== searchInput) {
            e.preventDefault();
            searchInput.focus();
        } else if (e.key === 'Escape' && document.activeElement === searchInput) {
            searchInput.value = '';
            searchInput.blur();
            executeTocFilter();
        }
    });

    function executeTocFilter() {
        const query = searchInput.value.trim().toLowerCase();
        let totalVisible = 0;
        let totalItems = 0;

        categoryCards.forEach(card => {
            const items = card.querySelectorAll('li');
            let visibleInCard = 0;

            items.forEach(li => {
                totalItems++;
                const text = li.textContent.toLowerCase();
                const dataSearch = (li.getAttribute('data-search') || '').toLowerCase();

                if (!query || text.includes(query) || dataSearch.includes(query)) {
                    li.style.display = 'list-item';
                    visibleInCard++;
                    totalVisible++;
                } else {
                    li.style.display = 'none';
                }
            });

            // Collapse card if no items match
            if (visibleInCard === 0 && query !== '') {
                card.style.display = 'none';
            } else {
                card.style.display = 'block';
            }
        });

        if (tocCounter) {
            tocCounter.textContent = query 
                ? `Showing ${totalVisible} of ${totalItems} Topics` 
                : `${totalItems} Topics`;
        }
    }
});
```
