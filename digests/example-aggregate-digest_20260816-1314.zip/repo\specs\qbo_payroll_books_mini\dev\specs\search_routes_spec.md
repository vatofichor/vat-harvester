# Specification Sheet: Client-Side Search & Dynamic Route Filtering Engine

```
# Copyright (c) 2026:
# vatofichor - Sebastian Mass     [>_<]
# & Assisted By Gemini Antigravity /|\  
```

This specification sheet provides a high-density architectural blueprint for dropping the **Live Search & Dynamic Card Filtering Engine** (as featured in [StartPage.html](file:///d:/Dev/qbo_bookkeeping_payroll_mod/dev/guides/StartPage.html)) into any web application or page.

---

## 1. System Architecture Overview

The search route system operates as a zero-dependency, zero-latency client-side DOM filter. It dynamically matches user input against target elements in real-time, executing attribute tokenization and DOM visibility updates without triggering layout thrashing or external network requests.

### Core Capabilities
- **Sub-Millisecond Response**: Real-time filtering on input keypress.
- **Enhanced Search Indexing**: Combines visible element text (`innerText`) with metadata tags (`data-search`).
- **Keyboard Navigation Hooks**: Press `/` anywhere on the page to focus search; press `Escape` to clear and unfocus.
- **Live Result Counter**: Automatically updates visible item counts.

---

## 2. Plug-and-Play Integration Blueprint

To drop this feature onto any custom HTML page, follow the 3-step contract below.

### Step 1: HTML Markup Contract

Place the search hero bar above your target grid or container, and add `data-search` attributes to your target items (cards, table rows, list items).

```html
<!-- Search Hero Bar Component -->
<div class="search-hero-section">
    <div class="search-container">
        <!-- Search SVG Icon -->
        <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        <!-- Search Input Field -->
        <input type="text" class="search-input" id="searchInput" placeholder="Search routes... (Press '/' to focus)">
        <!-- Shortcut Indicator Badge -->
        <span class="shortcut-badge">/</span>
    </div>
</div>

<!-- Section Header & Counter -->
<div class="section-header">
    <h2 class="section-title">Items Overview</h2>
    <span class="section-counter" id="itemCardsCounter">0 Items</span>
</div>

<!-- Grid or List Container -->
<div class="routes-hero-grid" id="routesGrid">
    <!-- Card Item Example 1 -->
    <a href="module-1.html" class="route-card" data-search="bookkeeping cheatsheet gaap balance ledger journal double entry">
        <div class="route-title">Bookkeeping Guide</div>
    </a>
    
    <!-- Card Item Example 2 (Table Rows or Custom Containers work identically) -->
    <a href="module-2.html" class="route-card" data-search="payroll taxes futa fica suta form 941 form 940 W-2">
        <div class="route-title">Payroll Tax Guide</div>
    </a>
</div>
```

---

### Step 2: CSS Styles & Layout Tokens

```css
:root {
    --bg-panel: #111827;
    --border-color: #1f293d;
    --text-main: #f3f4f6;
    --text-muted: #9ca3af;
    --accent: #6366f1;
    --accent-light: rgba(99, 102, 241, 0.15);
    --shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
}

.search-hero-section {
    padding: 20px 0;
    width: 100%;
}

.search-container {
    position: relative;
    width: 100%;
}

.search-input {
    width: 100%;
    padding: 14px 20px 14px 50px;
    background-color: var(--bg-panel);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    color: var(--text-main);
    font-size: 15px;
    outline: none;
    transition: all 0.2s ease;
}

.search-input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px var(--accent-light);
}

.search-icon {
    position: absolute;
    left: 18px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-muted);
    pointer-events: none;
}

.shortcut-badge {
    position: absolute;
    right: 16px;
    top: 50%;
    transform: translateY(-50%);
    background-color: var(--bg-panel);
    border: 1px solid var(--border-color);
    color: var(--text-muted);
    font-family: monospace;
    font-size: 12px;
    padding: 2px 7px;
    border-radius: 6px;
    pointer-events: none;
}
```

---

### Step 3: Vanilla JavaScript Engine

```javascript
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const itemsGrid = document.getElementById('routesGrid');
    const itemsCounter = document.getElementById('itemCardsCounter');
    let filterQuery = '';

    // 1. Live Input Event Listener
    searchInput.addEventListener('input', (e) => {
        filterQuery = e.target.value.trim().toLowerCase();
        executeFilter();
    });

    // 2. Keyboard Shortcuts ('/' to focus, 'Escape' to clear/blur)
    window.addEventListener('keydown', (e) => {
        if (e.key === '/' && document.activeElement !== searchInput) {
            e.preventDefault();
            searchInput.focus();
        } else if (e.key === 'Escape' && document.activeElement === searchInput) {
            searchInput.value = '';
            filterQuery = '';
            searchInput.blur();
            executeFilter();
        }
    });

    // 3. Core DOM Filtering Logic
    function executeFilter() {
        const cards = itemsGrid.querySelectorAll('.route-card');
        let visibleCount = 0;

        cards.forEach(card => {
            // Concatenate inner text and data-search metadata attribute for comprehensive matching
            const searchableText = (card.innerText + ' ' + (card.getAttribute('data-search') || '')).toLowerCase();

            if (!filterQuery || searchableText.includes(filterQuery)) {
                card.style.display = 'flex'; // Restore original layout display state
                visibleCount++;
            } else {
                card.style.display = 'none'; // Hide non-matching elements
            }
        });

        // Update Dynamic Counter
        if (itemsCounter) {
            itemsCounter.textContent = `${visibleCount} ${visibleCount === 1 ? 'Item' : 'Items'}`;
        }
    }

    // Initial Filter Execution
    executeFilter();
});
```

---

## 3. Customization & Layout Variations

### Adapting to Table Rows (`<tr>`)
To adapt this search engine for tabular data, replace `.route-card` with `tr.data-row`:
```javascript
const rows = tableBody.querySelectorAll('tr.data-row');
rows.forEach(row => {
    const text = (row.innerText + ' ' + (row.getAttribute('data-search') || '')).toLowerCase();
    row.style.display = (!filterQuery || text.includes(filterQuery)) ? '' : 'none';
});
```

### Text Node Highlighting Pattern
To dynamically highlight matching text substrings inside visible cards:
```javascript
function highlightMatch(element, query) {
    if (!query) return;
    const regex = new RegExp(`(${query})`, 'gi');
    element.innerHTML = element.textContent.replace(regex, '<mark class="search-highlight">$1</mark>');
}
```

---

## 4. NEW FEATURES DISCOVERY: Database & Enterprise Search Architecture

When scaling from static client-side DOM rows ($\le 500$ items) to large-scale database datasets ($10,000+$ rows) or enterprise applications, evaluate the following implementation paths:

### 4.1 Database Query Row Set Integration Patterns

```
                                [ User Query Input ]
                                         │
                 ┌───────────────────────┴───────────────────────┐
                 ▼                                               ▼
     [ Path A: Small-Medium Sets ]                   [ Path B: Large DB Sets ]
             (≤ 1,000 Rows)                                 (> 1,000 Rows)
                 │                                               │
       PHP / SQL Server-Side                             Debounced Fetch API
     Pre-render or JSON Hydrate                                 │
                 │                                      PHP / PDO Endpoint
      Client In-Memory Search                              SQL FULLTEXT / FTS5
                 │                                               │
       Sub-ms DOM Visibility                           JSON Payload Render
```

#### Option A: Client-Side In-Memory Hydration (PHP / PDO pre-render)
- **Mechanics**: Server executes a SQL query on initial page load (e.g., `SELECT id, title, keywords, payload FROM items WHERE active = 1`), rendering the rows or injecting them as a JS array:
  ```html
  <script>
      window.SEARCH_DATASET = <?php echo json_encode($dbRows); ?>;
  </script>
  ```
- **Pros**: Sub-millisecond instant filtering, zero DB load on search keypresses, offline capable.
- **Cons**: Memory overhead if row count exceeds several thousand items.

#### Option B: Debounced Server-Side Fetch Engine (PHP API + SQL Indexing)
- **Mechanics**: Attaches a `debounce()` wrapper (200ms-300ms delay) to `searchInput.input`. On query change, fires a fetch request to a server endpoint:
  ```javascript
  function debounce(func, delay = 250) {
      let timer;
      return (...args) => {
          clearTimeout(timer);
          timer = setTimeout(() => func.apply(this, args), delay);
      };
  }

  const performServerSearch = debounce(async (query) => {
      if (query.length < 2) return;
      const res = await fetch(`/api/search.php?q=${encodeURIComponent(query)}`);
      const data = await res.json();
      renderSearchResults(data);
  }, 250);
  ```

---

### 4.2 Popular Search Integrations & Third-Party Library Stacks

For enhanced search functionality beyond exact substring matching, integrate the following library paradigms:

| Stack / Library | Search Paradigm | Primary Use Case | Typo Tolerance |
| :--- | :--- | :--- | :--- |
| **Vanilla JS DOM** | Substring `String.includes()` | Small static routes / menus | No |
| **Fuse.js** | Lightweight Bitap Fuzzy Search | In-browser fuzzy client search | Yes (High) |
| **MiniSearch / Lunr.js** | In-Memory Inverted Index | Client-side full-text with field weights | Yes |
| **SQLite FTS5** | Server-side Virtual Table | Zero-dependency PHP + SQLite backend | Partial |
| **Meilisearch / Typesense** | Self-hosted REST Search Engine | Lightning fast enterprise DB search | Yes (Instant) |
| **Algolia** | Cloud Search API | Global SaaS multi-index search | Yes |

#### Integrating Fuse.js for Fuzzy & Typo-Tolerant Matching
```javascript
// Include Fuse.js CDN or ES Module
import Fuse from 'fuse.js';

const fuse = new Fuse(SEARCH_DATASET, {
    keys: ['title', 'keywords', 'tags'],
    threshold: 0.3, // Lower = stricter, Higher = fuzzier
    distance: 100
});

searchInput.addEventListener('input', (e) => {
    const results = fuse.search(e.target.value);
    renderCards(results.map(r => r.item));
});
```

---

### 4.3 Database SQL Indexing Specifications

When querying relational databases directly for row sets:

#### 1. SQLite FTS5 (Local PHP & Embedded DB Stack)
```sql
-- Create Virtual Full-Text Table
CREATE VIRTUAL TABLE items_fts USING fts5(title, content, keywords);

-- Query with BM25 Ranking
SELECT title, content, bm25(items_fts) AS rank
FROM items_fts
WHERE items_fts MATCH :query
ORDER BY rank;
```

#### 2. MySQL / MariaDB Full-Text Indexing
```sql
-- Add Full-Text Index
ALTER TABLE items ADD FULLTEXT INDEX ft_search_idx (title, description, keywords);

-- Execute Boolean Match Query
SELECT * FROM items 
WHERE MATCH(title, description, keywords) AGAINST(:query IN BOOLEAN MODE)
LIMIT 50;
```

#### 3. PostgreSQL `tsvector` & `GIN` Indexing
```sql
-- Create GIN Index on Document Vector
CREATE INDEX items_search_idx ON items USING GIN(to_tsvector('english', title || ' ' || keywords));

-- Search Query
SELECT * FROM items 
WHERE to_tsvector('english', title || ' ' || keywords) @@ plainto_tsquery('english', :query);
```

---

## 5. Architectural Verification & Summary

1. **Static Pages & Mini Hubs**: Deploy the **Vanilla JS + `data-search`** contract (Section 2) for zero-latency, zero-dependency performance.
2. **Dynamic DB Micro-Apps**: Use **Hydrated Client Dataset** (Section 4.1 Option A) for datasets $<1,000$ rows, or **Debounced Fetch + SQLite FTS5 / MySQL FULLTEXT** (Section 4.1 Option B) for larger datasets.
3. **Fuzzy Search Requirements**: Drop in **Fuse.js** when user typos and partial word matching are required.
